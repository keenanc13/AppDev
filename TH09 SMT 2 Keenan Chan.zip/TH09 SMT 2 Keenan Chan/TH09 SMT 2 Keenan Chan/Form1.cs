﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace TH09_SMT_2_Keenan_Chan
{
    public partial class Form1 : Form
    {
        DataTable dt = new DataTable();
        int hargaproduk1;
        int hargaproduk2;
        int hargaproduk3;
        int baris;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pan_normal.Visible = true;
            pan_other.Visible = false;
            
            pict_1.Image = Properties.Resources.canva_black_white_typography_motivation_tshirt_WKRZLU21i2c;
            pict_2.Image = Properties.Resources.canva_black_brush_style_inspirational_quote_t_shirt_iaKYylV3aYE;
            pict_3.Image = Properties.Resources._51_bdvcQLVL__AC_UY1100_;

            lb_1.Text = "T-Shirt 1";
            lb_2.Text = "T-Shirt 2";
            lb_3.Text = "T-Shirt 3";

            hargaproduk1 = 100000;
            hargaproduk2 = 150000;
            hargaproduk3 = 120000;

            lb_4.Text = $"Rp. {hargaproduk1.ToString("#,0.")}.-";
            lb_5.Text = $"Rp. {hargaproduk2.ToString("#,0.")}.-";
            lb_6.Text = $"Rp. {hargaproduk3.ToString("#,0.")}.-";
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pan_normal.Visible = true;
            pan_other.Visible = false;

            pict_1.Image = Properties.Resources.e6230a39_13b9_4b37_a872_bd34a5513bd8;
            pict_2.Image = Properties.Resources.images;
            pict_3.Image = Properties.Resources.shirt_noun_002_33400;

            lb_1.Text = "Shirt 1";
            lb_2.Text = "Shirt 2";
            lb_3.Text = "Shirt 3";

            hargaproduk1 = 200000;
            hargaproduk2 = 250000;
            hargaproduk3 = 220000;

            lb_4.Text = $"Rp. {hargaproduk1.ToString("#,0.")}.-";
            lb_5.Text = $"Rp. {hargaproduk2.ToString("#,0.")}.-";
            lb_6.Text = $"Rp. {hargaproduk3.ToString("#,0.")}.-";
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pan_normal.Visible = true;
            pan_other.Visible = false;

            pict_1.Image = Properties.Resources.Short_Chino_Olive_4_1;
            pict_2.Image = Properties.Resources.Relaxed_Short_6;
            pict_3.Image = Properties.Resources.PAAC_BRT0087_PTE003N_06_sf;

            lb_1.Text = "Pants 1";
            lb_2.Text = "Pants 2";
            lb_3.Text = "Pants 3";

            hargaproduk1 = 150000;
            hargaproduk2 = 170000;
            hargaproduk3 = 180000;

            lb_4.Text = $"Rp. {hargaproduk1.ToString("#,0.")}.-";
            lb_5.Text = $"Rp. {hargaproduk2.ToString("#,0.")}.-";
            lb_6.Text = $"Rp. {hargaproduk3.ToString("#,0.")}.-";
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pan_normal.Visible = true;
            pan_other.Visible = false;

            pict_1.Image = Properties.Resources.corduroy_long_pants;
            pict_2.Image = Properties.Resources.black_long_pants;
            pict_3.Image = Properties.Resources.blue_pants;

            lb_1.Text = "Long Pants 1";
            lb_2.Text = "Long Pants 2";
            lb_3.Text = "Long Pants 3";

            hargaproduk1 = 200000;
            hargaproduk2 = 220000;
            hargaproduk3 = 250000;

            lb_4.Text = $"Rp. {hargaproduk1.ToString("#,0.")}.-";
            lb_5.Text = $"Rp. {hargaproduk2.ToString("#,0.")}.-";
            lb_6.Text = $"Rp. {hargaproduk3.ToString("#,0.")}.-";
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pan_normal.Visible = true;
            pan_other.Visible = false;

            pict_1.Image = Properties.Resources.pexels_webdonut_19090;
            pict_2.Image = Properties.Resources.rainbow_shoes;
            pict_3.Image = Properties.Resources.red_shoes;

            lb_1.Text = "Shoes 1";
            lb_2.Text = "Shoes 2";
            lb_3.Text = "Shoes 3";

            hargaproduk1 = 300000;
            hargaproduk2 = 350000;
            hargaproduk3 = 320000;

            lb_4.Text = $"Rp. {hargaproduk1.ToString("#,0.")}.-";
            lb_5.Text = $"Rp. {hargaproduk2.ToString("#,0.")}.-";
            lb_6.Text = $"Rp. {hargaproduk3.ToString("#,0.")}.-";
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pan_normal.Visible = true;
            pan_other.Visible = false;

            pict_1.Image = Properties.Resources.km66phn8_earrings650_625x300_03_October_22;
            pict_2.Image = Properties.Resources.ring;
            pict_3.Image = Properties.Resources.gold_necklace;

            lb_1.Text = "Jewellery 1";
            lb_2.Text = "Jewellery 2";
            lb_3.Text = "Jewellery 3";

            hargaproduk1 = 1000000;
            hargaproduk2 = 1500000;
            hargaproduk3 = 1200000;

            lb_4.Text = $"Rp. {hargaproduk1.ToString("#,0.")}.-";
            lb_5.Text = $"Rp. {hargaproduk2.ToString("#,0.")}.-";
            lb_6.Text = $"Rp. {hargaproduk3.ToString("#,0.")}.-";
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pan_normal.Visible = false;
            pan_other.Visible = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pan_normal.Visible = false;
            pan_other.Visible = false;

            pan_other.Location = new Point(-25, 40);

            dt.Columns.Add("Item Name");
            dt.Columns.Add("Quantity");
            dt.Columns.Add("Price");
            dt.Columns.Add("Total");

            tb_itemname.Enabled = false;
            tb_itemprice.Enabled = false;
            btn_addtocart.Enabled = false;
        }

        private void btn_Add1_Click(object sender, EventArgs e)
        {
            AddProduk(lb_1.Text, hargaproduk1);
               
        }

        private void AddProduk(string labelprod, int price)
        {
            dgv_dt.DataSource = dt;
            int quant;
            bool masuk = false;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i]["Item Name"].ToString() == labelprod)
                {
                    quant = Convert.ToInt32(dt.Rows[i]["Quantity"]) + 1;
                    dt.Rows[i]["Quantity"] = quant;
                    dt.Rows[i]["Total"] = quant * price;

                    masuk = true;
                    break;
                }
            }

            if (masuk == false)
            {
                dt.Rows.Add(labelprod, 1, price, price);
            }

            int subtotal = 0;
            for(int i = 0;i < dt.Rows.Count; i++)
            {
                subtotal += Convert.ToInt32(dt.Rows[i]["Total"]);
            }
            tb_Subtotal.Text = $"Rp. {subtotal.ToString("#,0.")}";

            double total = subtotal + subtotal * 0.1;
            tb_Total.Text = $"Rp. {total.ToString("#,0.")}";
        }

        private void btn_Add2_Click(object sender, EventArgs e)
        {
            AddProduk(lb_2.Text, hargaproduk2);
        }

        private void btn_Add3_Click(object sender, EventArgs e)
        {
            AddProduk(lb_3.Text, hargaproduk3);
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (baris >= 0 & dt.Rows.Count > 0)
            {
                dt.Rows.RemoveAt(baris);
                dgv_dt.DataSource = dt;

                int subTotal = 0;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    subTotal += Convert.ToInt32(dt.Rows[i]["Total"]);
                }
                tb_Subtotal.Text = "Rp. " + subTotal.ToString("#,0.") + ".";

                double total = subTotal + subTotal * 0.1;
                tb_Total.Text = "Rp. " + total.ToString("#,0.") + ".";


            }

        }

        private void dgv_dt_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            baris = e.RowIndex;
        }

        private void btn_upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files (*.jpg, *.png, *.bmp)|*.jpg; *.png; *.bmp|All files(.)|*.*";
            ofd.Multiselect = true;

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pict_others.Image = Image.FromFile(ofd.FileName);
                tb_itemname.Enabled = true;
                tb_itemprice.Enabled = true;
            }
        }

        private void btn_addtocart_Click(object sender, EventArgs e)
        {
            AddProduk(tb_itemname.Text, Convert.ToInt32(tb_itemprice.Text));
        }

        private void tb_itemprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tb_itemname_TextChanged(object sender, EventArgs e)
        {
            if(tb_itemname.Text != "" && tb_itemprice.Text != "")
            {
                btn_addtocart.Enabled = true;
            }
            else if (tb_itemname.Text != " " || tb_itemprice.Text != " ")
            {
                btn_addtocart.Enabled = false;
            }
        }

        private void tb_itemprice_TextChanged(object sender, EventArgs e)
        {
            if (tb_itemname.Text != "" && tb_itemprice.Text != "")
            {
                btn_addtocart.Enabled = true;
            }
            else if (tb_itemname.Text != " " || tb_itemprice.Text != " ")
            {
                btn_addtocart.Enabled = false;
            }
        }
    }
}
