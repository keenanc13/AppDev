﻿namespace TH09_SMT_2_Keenan_Chan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_dt = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lb_Subtotal = new System.Windows.Forms.Label();
            this.lb_Total = new System.Windows.Forms.Label();
            this.tb_Subtotal = new System.Windows.Forms.TextBox();
            this.tb_Total = new System.Windows.Forms.TextBox();
            this.pan_normal = new System.Windows.Forms.Panel();
            this.lb_6 = new System.Windows.Forms.Label();
            this.lb_5 = new System.Windows.Forms.Label();
            this.lb_4 = new System.Windows.Forms.Label();
            this.lb_3 = new System.Windows.Forms.Label();
            this.lb_2 = new System.Windows.Forms.Label();
            this.lb_1 = new System.Windows.Forms.Label();
            this.pict_1 = new System.Windows.Forms.PictureBox();
            this.btn_Add3 = new System.Windows.Forms.Button();
            this.btn_Add2 = new System.Windows.Forms.Button();
            this.btn_Add1 = new System.Windows.Forms.Button();
            this.pict_3 = new System.Windows.Forms.PictureBox();
            this.pict_2 = new System.Windows.Forms.PictureBox();
            this.pan_other = new System.Windows.Forms.Panel();
            this.tb_itemprice = new System.Windows.Forms.TextBox();
            this.tb_itemname = new System.Windows.Forms.TextBox();
            this.btn_addtocart = new System.Windows.Forms.Button();
            this.btn_upload = new System.Windows.Forms.Button();
            this.pict_others = new System.Windows.Forms.PictureBox();
            this.lb_itemprice = new System.Windows.Forms.Label();
            this.lb_itemname = new System.Windows.Forms.Label();
            this.lb_upload = new System.Windows.Forms.Label();
            this.btn_delete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_dt)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.pan_normal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pict_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pict_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pict_2)).BeginInit();
            this.pan_other.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pict_others)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_dt
            // 
            this.dgv_dt.AllowUserToAddRows = false;
            this.dgv_dt.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_dt.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_dt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_dt.Location = new System.Drawing.Point(738, 57);
            this.dgv_dt.Name = "dgv_dt";
            this.dgv_dt.RowHeadersVisible = false;
            this.dgv_dt.RowHeadersWidth = 62;
            this.dgv_dt.RowTemplate.Height = 28;
            this.dgv_dt.Size = new System.Drawing.Size(522, 377);
            this.dgv_dt.TabIndex = 0;
            this.dgv_dt.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_dt_CellClick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1373, 33);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(102, 29);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(133, 29);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accToolStripMenuItem
            // 
            this.accToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.accToolStripMenuItem.Name = "accToolStripMenuItem";
            this.accToolStripMenuItem.Size = new System.Drawing.Size(119, 29);
            this.accToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(195, 34);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(195, 34);
            this.jewelleriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelleriesToolStripMenuItem.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(81, 29);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // lb_Subtotal
            // 
            this.lb_Subtotal.AutoSize = true;
            this.lb_Subtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Subtotal.Location = new System.Drawing.Point(732, 446);
            this.lb_Subtotal.Name = "lb_Subtotal";
            this.lb_Subtotal.Size = new System.Drawing.Size(156, 32);
            this.lb_Subtotal.TabIndex = 2;
            this.lb_Subtotal.Text = "Sub-Total:";
            // 
            // lb_Total
            // 
            this.lb_Total.AutoSize = true;
            this.lb_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Total.Location = new System.Drawing.Point(796, 487);
            this.lb_Total.Name = "lb_Total";
            this.lb_Total.Size = new System.Drawing.Size(92, 32);
            this.lb_Total.TabIndex = 3;
            this.lb_Total.Text = "Total:";
            // 
            // tb_Subtotal
            // 
            this.tb_Subtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Subtotal.Location = new System.Drawing.Point(894, 452);
            this.tb_Subtotal.Name = "tb_Subtotal";
            this.tb_Subtotal.ReadOnly = true;
            this.tb_Subtotal.Size = new System.Drawing.Size(366, 30);
            this.tb_Subtotal.TabIndex = 4;
            // 
            // tb_Total
            // 
            this.tb_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Total.Location = new System.Drawing.Point(894, 493);
            this.tb_Total.Name = "tb_Total";
            this.tb_Total.ReadOnly = true;
            this.tb_Total.Size = new System.Drawing.Size(366, 30);
            this.tb_Total.TabIndex = 5;
            // 
            // pan_normal
            // 
            this.pan_normal.Controls.Add(this.lb_6);
            this.pan_normal.Controls.Add(this.lb_5);
            this.pan_normal.Controls.Add(this.lb_4);
            this.pan_normal.Controls.Add(this.lb_3);
            this.pan_normal.Controls.Add(this.lb_2);
            this.pan_normal.Controls.Add(this.lb_1);
            this.pan_normal.Controls.Add(this.pict_1);
            this.pan_normal.Controls.Add(this.btn_Add3);
            this.pan_normal.Controls.Add(this.btn_Add2);
            this.pan_normal.Controls.Add(this.btn_Add1);
            this.pan_normal.Controls.Add(this.pict_3);
            this.pan_normal.Controls.Add(this.pict_2);
            this.pan_normal.Location = new System.Drawing.Point(22, 57);
            this.pan_normal.Name = "pan_normal";
            this.pan_normal.Size = new System.Drawing.Size(699, 383);
            this.pan_normal.TabIndex = 6;
            // 
            // lb_6
            // 
            this.lb_6.AutoSize = true;
            this.lb_6.Location = new System.Drawing.Point(499, 287);
            this.lb_6.Name = "lb_6";
            this.lb_6.Size = new System.Drawing.Size(39, 20);
            this.lb_6.TabIndex = 12;
            this.lb_6.Text = "lb_6";
            // 
            // lb_5
            // 
            this.lb_5.AutoSize = true;
            this.lb_5.Location = new System.Drawing.Point(280, 287);
            this.lb_5.Name = "lb_5";
            this.lb_5.Size = new System.Drawing.Size(39, 20);
            this.lb_5.TabIndex = 11;
            this.lb_5.Text = "lb_5";
            // 
            // lb_4
            // 
            this.lb_4.AutoSize = true;
            this.lb_4.Location = new System.Drawing.Point(63, 287);
            this.lb_4.Name = "lb_4";
            this.lb_4.Size = new System.Drawing.Size(39, 20);
            this.lb_4.TabIndex = 10;
            this.lb_4.Text = "lb_4";
            // 
            // lb_3
            // 
            this.lb_3.AutoSize = true;
            this.lb_3.Location = new System.Drawing.Point(518, 254);
            this.lb_3.Name = "lb_3";
            this.lb_3.Size = new System.Drawing.Size(39, 20);
            this.lb_3.TabIndex = 9;
            this.lb_3.Text = "lb_3";
            // 
            // lb_2
            // 
            this.lb_2.AutoSize = true;
            this.lb_2.Location = new System.Drawing.Point(305, 254);
            this.lb_2.Name = "lb_2";
            this.lb_2.Size = new System.Drawing.Size(39, 20);
            this.lb_2.TabIndex = 8;
            this.lb_2.Text = "lb_2";
            // 
            // lb_1
            // 
            this.lb_1.AutoSize = true;
            this.lb_1.Location = new System.Drawing.Point(80, 254);
            this.lb_1.Name = "lb_1";
            this.lb_1.Size = new System.Drawing.Size(39, 20);
            this.lb_1.TabIndex = 7;
            this.lb_1.Text = "lb_1";
            // 
            // pict_1
            // 
            this.pict_1.Location = new System.Drawing.Point(44, 29);
            this.pict_1.Name = "pict_1";
            this.pict_1.Size = new System.Drawing.Size(157, 210);
            this.pict_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pict_1.TabIndex = 6;
            this.pict_1.TabStop = false;
            // 
            // btn_Add3
            // 
            this.btn_Add3.Location = new System.Drawing.Point(503, 324);
            this.btn_Add3.Name = "btn_Add3";
            this.btn_Add3.Size = new System.Drawing.Size(109, 29);
            this.btn_Add3.TabIndex = 5;
            this.btn_Add3.Text = "Add to Cart";
            this.btn_Add3.UseVisualStyleBackColor = true;
            this.btn_Add3.Click += new System.EventHandler(this.btn_Add3_Click);
            // 
            // btn_Add2
            // 
            this.btn_Add2.Location = new System.Drawing.Point(284, 324);
            this.btn_Add2.Name = "btn_Add2";
            this.btn_Add2.Size = new System.Drawing.Size(109, 29);
            this.btn_Add2.TabIndex = 4;
            this.btn_Add2.Text = "Add to Cart";
            this.btn_Add2.UseVisualStyleBackColor = true;
            this.btn_Add2.Click += new System.EventHandler(this.btn_Add2_Click);
            // 
            // btn_Add1
            // 
            this.btn_Add1.Location = new System.Drawing.Point(67, 324);
            this.btn_Add1.Name = "btn_Add1";
            this.btn_Add1.Size = new System.Drawing.Size(102, 29);
            this.btn_Add1.TabIndex = 3;
            this.btn_Add1.Text = "Add to Cart";
            this.btn_Add1.UseVisualStyleBackColor = true;
            this.btn_Add1.Click += new System.EventHandler(this.btn_Add1_Click);
            // 
            // pict_3
            // 
            this.pict_3.Location = new System.Drawing.Point(483, 29);
            this.pict_3.Name = "pict_3";
            this.pict_3.Size = new System.Drawing.Size(146, 210);
            this.pict_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pict_3.TabIndex = 2;
            this.pict_3.TabStop = false;
            // 
            // pict_2
            // 
            this.pict_2.Location = new System.Drawing.Point(269, 29);
            this.pict_2.Name = "pict_2";
            this.pict_2.Size = new System.Drawing.Size(157, 210);
            this.pict_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pict_2.TabIndex = 1;
            this.pict_2.TabStop = false;
            // 
            // pan_other
            // 
            this.pan_other.Controls.Add(this.tb_itemprice);
            this.pan_other.Controls.Add(this.tb_itemname);
            this.pan_other.Controls.Add(this.btn_addtocart);
            this.pan_other.Controls.Add(this.btn_upload);
            this.pan_other.Controls.Add(this.pict_others);
            this.pan_other.Controls.Add(this.lb_itemprice);
            this.pan_other.Controls.Add(this.lb_itemname);
            this.pan_other.Controls.Add(this.lb_upload);
            this.pan_other.Location = new System.Drawing.Point(22, 475);
            this.pan_other.Name = "pan_other";
            this.pan_other.Size = new System.Drawing.Size(699, 380);
            this.pan_other.TabIndex = 7;
            // 
            // tb_itemprice
            // 
            this.tb_itemprice.Location = new System.Drawing.Point(390, 188);
            this.tb_itemprice.Name = "tb_itemprice";
            this.tb_itemprice.Size = new System.Drawing.Size(237, 26);
            this.tb_itemprice.TabIndex = 7;
            this.tb_itemprice.TextChanged += new System.EventHandler(this.tb_itemprice_TextChanged);
            this.tb_itemprice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_itemprice_KeyPress);
            // 
            // tb_itemname
            // 
            this.tb_itemname.Location = new System.Drawing.Point(390, 110);
            this.tb_itemname.Name = "tb_itemname";
            this.tb_itemname.Size = new System.Drawing.Size(237, 26);
            this.tb_itemname.TabIndex = 6;
            this.tb_itemname.TextChanged += new System.EventHandler(this.tb_itemname_TextChanged);
            // 
            // btn_addtocart
            // 
            this.btn_addtocart.Location = new System.Drawing.Point(390, 308);
            this.btn_addtocart.Name = "btn_addtocart";
            this.btn_addtocart.Size = new System.Drawing.Size(128, 36);
            this.btn_addtocart.TabIndex = 5;
            this.btn_addtocart.Text = "Add to Cart";
            this.btn_addtocart.UseVisualStyleBackColor = true;
            this.btn_addtocart.Click += new System.EventHandler(this.btn_addtocart_Click);
            // 
            // btn_upload
            // 
            this.btn_upload.Location = new System.Drawing.Point(318, 25);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(125, 35);
            this.btn_upload.TabIndex = 4;
            this.btn_upload.Text = "Upload";
            this.btn_upload.UseVisualStyleBackColor = true;
            this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click);
            // 
            // pict_others
            // 
            this.pict_others.Location = new System.Drawing.Point(172, 74);
            this.pict_others.Name = "pict_others";
            this.pict_others.Size = new System.Drawing.Size(184, 286);
            this.pict_others.TabIndex = 3;
            this.pict_others.TabStop = false;
            // 
            // lb_itemprice
            // 
            this.lb_itemprice.AutoSize = true;
            this.lb_itemprice.Location = new System.Drawing.Point(386, 153);
            this.lb_itemprice.Name = "lb_itemprice";
            this.lb_itemprice.Size = new System.Drawing.Size(84, 20);
            this.lb_itemprice.TabIndex = 2;
            this.lb_itemprice.Text = "Item Price:";
            // 
            // lb_itemname
            // 
            this.lb_itemname.AutoSize = true;
            this.lb_itemname.Location = new System.Drawing.Point(386, 83);
            this.lb_itemname.Name = "lb_itemname";
            this.lb_itemname.Size = new System.Drawing.Size(91, 20);
            this.lb_itemname.TabIndex = 1;
            this.lb_itemname.Text = "Item Name:";
            // 
            // lb_upload
            // 
            this.lb_upload.AutoSize = true;
            this.lb_upload.Location = new System.Drawing.Point(203, 30);
            this.lb_upload.Name = "lb_upload";
            this.lb_upload.Size = new System.Drawing.Size(109, 20);
            this.lb_upload.TabIndex = 0;
            this.lb_upload.Text = "Upload Image";
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(1172, 548);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(88, 35);
            this.btn_delete.TabIndex = 8;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1373, 690);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.pan_other);
            this.Controls.Add(this.pan_normal);
            this.Controls.Add(this.tb_Total);
            this.Controls.Add(this.tb_Subtotal);
            this.Controls.Add(this.lb_Total);
            this.Controls.Add(this.lb_Subtotal);
            this.Controls.Add(this.dgv_dt);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_dt)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.pan_normal.ResumeLayout(false);
            this.pan_normal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pict_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pict_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pict_2)).EndInit();
            this.pan_other.ResumeLayout(false);
            this.pan_other.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pict_others)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_dt;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.Label lb_Subtotal;
        private System.Windows.Forms.Label lb_Total;
        private System.Windows.Forms.TextBox tb_Subtotal;
        private System.Windows.Forms.TextBox tb_Total;
        private System.Windows.Forms.Panel pan_normal;
        private System.Windows.Forms.PictureBox pict_3;
        private System.Windows.Forms.PictureBox pict_2;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.Button btn_Add3;
        private System.Windows.Forms.Button btn_Add2;
        private System.Windows.Forms.Button btn_Add1;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.PictureBox pict_1;
        private System.Windows.Forms.Label lb_3;
        private System.Windows.Forms.Label lb_2;
        private System.Windows.Forms.Label lb_1;
        private System.Windows.Forms.Label lb_6;
        private System.Windows.Forms.Label lb_5;
        private System.Windows.Forms.Label lb_4;
        private System.Windows.Forms.Panel pan_other;
        private System.Windows.Forms.TextBox tb_itemprice;
        private System.Windows.Forms.TextBox tb_itemname;
        private System.Windows.Forms.Button btn_addtocart;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.PictureBox pict_others;
        private System.Windows.Forms.Label lb_itemprice;
        private System.Windows.Forms.Label lb_itemname;
        private System.Windows.Forms.Label lb_upload;
        private System.Windows.Forms.Button btn_delete;
    }
}

