﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH05_Keenan
{
    public partial class form_shop : Form
    {
        DataTable dtProdukSimpan;
        DataTable dtProdukTampil;
        DataTable dtCategory;
        public form_shop()
        {
            InitializeComponent();
            tb_harga.KeyPress += tb_harga_KeyPress;
            tb_stock.KeyPress += tb_stock_KeyPress;
        }

        private void form_shop_Load(object sender, EventArgs e)
        {
            combo_filter.Enabled = false;
            dtProdukSimpan = new DataTable();
            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");
            dtProdukSimpan.Rows.Add("J001","Jas Hitam",100000,10,"C1");
            dtProdukSimpan.Rows.Add("T001", "T-Shirt Black Pink", 70000, 20, "C2");
            dtProdukSimpan.Rows.Add("T002", "T-Shirt Obsessive", 75000, 16, "C2");
            dtProdukSimpan.Rows.Add("R001", "Rok mini", 82000, 26, "C3");
            dtProdukSimpan.Rows.Add("J002", "Jeans Biru", 90000, 5, "C4");
            dtProdukSimpan.Rows.Add("C001", "Celana Pendek Coklat", 60000, 11, "C4");
            dtProdukSimpan.Rows.Add("C002", "Cawat Blink-blink", 1000000, 1, "C5");
            dtProdukSimpan.Rows.Add("R002", "Rocca Shirt", 50000, 8, "C2");
            dgv_Product.DataSource = dtProdukSimpan;

            dtCategory = new DataTable();
            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");
            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-Shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Cawat");
            dgv_Category.DataSource = dtCategory;

           dgv_Category.ClearSelection();
            dgv_Product.ClearSelection();
        }

        private void btn_filter_Click(object sender, EventArgs e)
        {
            combo_filter.Enabled = true;
        }

        private void combo_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            string filter = "";
            dtProdukTampil = new DataTable();
            dtProdukTampil.Columns.Add("ID Product");
            dtProdukTampil.Columns.Add("Nama Product");
            dtProdukTampil.Columns.Add("Harga");
            dtProdukTampil.Columns.Add("Stock");
            dtProdukTampil.Columns.Add("ID Category");
            dgv_Product.DataSource = dtProdukTampil;

            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dtCategory.Rows[i][1].ToString() == combo_filter.Text)
                {
                    filter = dtCategory.Rows[i][0].ToString();
                }
            }
            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                if (dtProdukSimpan.Rows[i][4].ToString().Contains(filter))
                {
                    dtProdukTampil.Rows.Add(dtProdukSimpan.Rows[i][0].ToString(), dtProdukSimpan.Rows[i][1].ToString(), dtProdukSimpan.Rows[i][2].ToString(),dtProdukSimpan.Rows[i][3].ToString(),dtProdukSimpan.Rows[i][4].ToString());
                }
            }
            dgv_Product.ClearSelection();
        }

        private void btn_All_Click(object sender, EventArgs e)
        {
            combo_filter.Enabled = false;
            dgv_Product.DataSource = dtProdukSimpan;
            combo_filter.SelectedIndex = -1;
            dgv_Product.ClearSelection();
        }

        private void btn_Removecat_Click(object sender, EventArgs e)
        {
            DataGridViewRow index = dgv_Category.CurrentRow;
            int count = 0;
            int totalrow = dtProdukSimpan.Rows.Count;
            for (int i = 0; i < totalrow; i++)
            {
                if (count == 0)
                {
                    if (index.Cells[0].Value.ToString() == dtProdukSimpan.Rows[i][4].ToString())
                    {
                        dtProdukSimpan.Rows.RemoveAt(i);
                        count++;
                    }
                }
                else if (count != 0)
                {
                    if (index.Cells[0].Value.ToString() == dtProdukSimpan.Rows[i-count][4].ToString())
                    {
                        dtProdukSimpan.Rows.RemoveAt(i - count);
                        count++;
                    }
                }
            }
            dgv_Category.Rows.Remove(index);
            tb_namacat.Clear();

            dgv_Product.DataSource = dtProdukSimpan;
        }

        private void btn_Addcat_Click(object sender, EventArgs e)
        {
            bool ada = false;
            
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (tb_namacat.Text.ToUpper() == dtCategory.Rows[i][1].ToString().ToUpper())
                {
                    ada = true;
                }
            }
            if (tb_namacat.Text == "")
            {
                MessageBox.Show("Masukkan nama category terlebih dahulu");
            }
            else if (ada != false)
            {
                MessageBox.Show("Category sudah ada");
            }
            else
            {
                if (dtCategory.Rows.Count == 0)
                {
                    dtCategory.Rows.Add("C1", tb_namacat.Text);
                }
                else
                {
                    string tempcategory = dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString();
                    int nomor = Convert.ToInt32(tempcategory.Remove(0, 1)) + 1;

                    dtCategory.Rows.Add("C" + nomor.ToString(), tb_namacat.Text);
                }
                
            }

            combo_filter.Items.Clear();
            combo_category.Items.Clear();
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                combo_filter.Items.Add(dtCategory.Rows[i][1].ToString());
                combo_category.Items.Add(dtCategory.Rows[i][1].ToString());
            }
            tb_namacat.Text = "";

            
        }

        private void dgv_Product_Click(object sender, EventArgs e)
        {
            DataGridViewRow currentRow = dgv_Product.CurrentRow;
            tb_namaprod.Text = currentRow.Cells[1].Value.ToString();
            tb_harga.Text = currentRow.Cells[2].Value. ToString();
            tb_stock.Text = currentRow.Cells[3].Value.ToString();

            for (int i = 0;i < dtCategory.Rows.Count; i++)
            {
                if (currentRow.Cells[4].Value.ToString() == dtCategory.Rows[i][0].ToString())
                {
                    combo_category.Text = dtCategory.Rows[i][1].ToString();
                    break;
                }
            }
        }

        private void dgv_Category_Click(object sender, EventArgs e)
        {
            DataGridViewRow currentRow = dgv_Category.CurrentRow;
            tb_namacat.Text = currentRow.Cells[1].Value.ToString();
        }

        private void btn_Editprod_Click(object sender, EventArgs e)
        {
            if (tb_namaprod.Text == "")
            {
                MessageBox.Show("Pilih produk terlebih dahulu");
            }
            else if (tb_stock.Text == "0")
            {
                DataGridViewRow currentrow = dgv_Product.CurrentRow;
                dgv_Product.Rows.Remove(currentrow);
            }
            else
            {
                dgv_Product.Rows[dgv_Product.CurrentRow.Index].Cells[1].Value = tb_namaprod.Text;
                dgv_Product.Rows[dgv_Product.CurrentRow.Index].Cells[2].Value = tb_harga.Text;
                dgv_Product.Rows[dgv_Product.CurrentRow.Index].Cells[3].Value = tb_stock.Text;

                for (int i = 0; i < dgv_Category.Rows.Count; i++)
                {
                    if (combo_category.Text == dtCategory.Rows[i][1].ToString())
                    {
                        dgv_Product.Rows[dgv_Product.CurrentRow.Index].Cells[4].Value = dtCategory.Rows[i][0].ToString();
                        break;
                    }
                }
            }
            tb_namaprod.Text = "";
            combo_category.SelectedIndex = -1;
            tb_harga.Text = "";
            tb_stock.Text = "";
        }

        private void btn_Addprod_Click(object sender, EventArgs e)
        {
            int id = 0;
            string kode = "";
            string hasilid = "";
            string huruf = tb_namaprod.Text.ToString().Substring(0,1).ToUpper();
            if (tb_namaprod.Text == "" || combo_category.SelectedIndex == -1 || tb_harga.Text == "" || tb_stock.Text == "")
            {
                MessageBox.Show("Input yang lengkap ya");
            }
            else
            {
                for(int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i][0].ToString().Substring(0,1) == tb_namaprod.Text.ToString().Substring(0, 1).ToUpper())
                    {
                        int nomer = Convert.ToInt32(dtProdukSimpan.Rows[i][0].ToString().Substring(1));
                        if(nomer > id)
                        {
                            id = nomer;
                        }
                    }
                }
                id++;
                if(id < 10)
                {
                    hasilid = $"{huruf}00{id}";
                }
                else if (id < 100)
                {
                    hasilid = $"{huruf}0{id}";
                }
                else if (id < 1000)
                {
                    hasilid = $"{huruf}{id}";
                }
                for(int i = 0; i < dgv_Category.Rows.Count; i++)
                {
                    if(combo_category.Text == dtCategory.Rows[i][1].ToString())
                    {
                        kode = dtCategory.Rows[i][0].ToString();
                        break;
                    }
                }
                dtProdukSimpan.Rows.Add(hasilid,tb_namaprod.Text,tb_harga.Text,tb_stock.Text,kode);
                dgv_Product.DataSource = dtProdukSimpan;
                tb_namaprod.Text = "";
                combo_category.SelectedIndex = -1;
                tb_harga.Text = "";
                tb_stock.Text = "";
            }          
        }

        private void btn_RemoveProd_Click(object sender, EventArgs e)
        {
            
            if(dgv_Product.SelectedRows.Count == 0)
            {
                MessageBox.Show("Pilih produk terlebih dahulu");
            }

            if (tb_namaprod.Text != "")
            {
                DataGridViewRow dr = dgv_Product.CurrentRow;
                int index = dgv_Product.CurrentRow.Index;

                dgv_Product.DataSource = dtProdukSimpan;

                for(int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i][0].ToString() == dtProdukTampil.Rows[index][0].ToString())
                    {
                        dtProdukSimpan.Rows.RemoveAt(i);
                    }
                }
                combo_filter.SelectedIndex = -1;
            }
            else
            {
                foreach(DataGridViewRow currentrow in dgv_Product.SelectedRows)
                {
                    dgv_Product.Rows.RemoveAt(currentrow.Index);
                }
               
                
            }
            tb_namaprod.Text = "";
            combo_category.SelectedIndex = -1;
            tb_harga.Text = "";
            tb_stock.Text = "";
        }

        private void tb_harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tb_stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}

