﻿namespace TH05_Keenan
{
    partial class form_shop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_shop));
            this.dgv_Product = new System.Windows.Forms.DataGridView();
            this.dgv_Category = new System.Windows.Forms.DataGridView();
            this.lb_prod = new System.Windows.Forms.Label();
            this.lb_cat = new System.Windows.Forms.Label();
            this.lb_det = new System.Windows.Forms.Label();
            this.lb_nam = new System.Windows.Forms.Label();
            this.lb_category = new System.Windows.Forms.Label();
            this.lb_harga = new System.Windows.Forms.Label();
            this.lb_stock = new System.Windows.Forms.Label();
            this.lb_nama = new System.Windows.Forms.Label();
            this.tb_namaprod = new System.Windows.Forms.TextBox();
            this.tb_harga = new System.Windows.Forms.TextBox();
            this.tb_stock = new System.Windows.Forms.TextBox();
            this.tb_namacat = new System.Windows.Forms.TextBox();
            this.btn_All = new System.Windows.Forms.Button();
            this.btn_filter = new System.Windows.Forms.Button();
            this.btn_Addprod = new System.Windows.Forms.Button();
            this.btn_Editprod = new System.Windows.Forms.Button();
            this.btn_Removepod = new System.Windows.Forms.Button();
            this.btn_Addcat = new System.Windows.Forms.Button();
            this.btn_Removecat = new System.Windows.Forms.Button();
            this.combo_filter = new System.Windows.Forms.ComboBox();
            this.combo_category = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Category)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_Product
            // 
            this.dgv_Product.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_Product.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_Product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Product.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_Product.EnableHeadersVisualStyles = false;
            this.dgv_Product.Location = new System.Drawing.Point(64, 73);
            this.dgv_Product.Name = "dgv_Product";
            this.dgv_Product.RowHeadersVisible = false;
            this.dgv_Product.RowHeadersWidth = 62;
            this.dgv_Product.RowTemplate.Height = 28;
            this.dgv_Product.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Product.Size = new System.Drawing.Size(575, 317);
            this.dgv_Product.TabIndex = 0;
            this.dgv_Product.Click += new System.EventHandler(this.dgv_Product_Click);
            // 
            // dgv_Category
            // 
            this.dgv_Category.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_Category.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_Category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Category.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_Category.Location = new System.Drawing.Point(870, 73);
            this.dgv_Category.Name = "dgv_Category";
            this.dgv_Category.RowHeadersVisible = false;
            this.dgv_Category.RowHeadersWidth = 62;
            this.dgv_Category.RowTemplate.Height = 28;
            this.dgv_Category.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Category.Size = new System.Drawing.Size(342, 220);
            this.dgv_Category.TabIndex = 1;
            this.dgv_Category.Click += new System.EventHandler(this.dgv_Category_Click);
            // 
            // lb_prod
            // 
            this.lb_prod.AutoSize = true;
            this.lb_prod.Font = new System.Drawing.Font("Microsoft Tai Le", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_prod.Location = new System.Drawing.Point(58, 22);
            this.lb_prod.Name = "lb_prod";
            this.lb_prod.Size = new System.Drawing.Size(118, 35);
            this.lb_prod.TabIndex = 2;
            this.lb_prod.Text = "Product";
            // 
            // lb_cat
            // 
            this.lb_cat.AutoSize = true;
            this.lb_cat.Font = new System.Drawing.Font("Microsoft Tai Le", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_cat.Location = new System.Drawing.Point(864, 21);
            this.lb_cat.Name = "lb_cat";
            this.lb_cat.Size = new System.Drawing.Size(133, 35);
            this.lb_cat.TabIndex = 3;
            this.lb_cat.Text = "Category";
            // 
            // lb_det
            // 
            this.lb_det.AutoSize = true;
            this.lb_det.Font = new System.Drawing.Font("Microsoft Tai Le", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_det.Location = new System.Drawing.Point(58, 410);
            this.lb_det.Name = "lb_det";
            this.lb_det.Size = new System.Drawing.Size(105, 35);
            this.lb_det.TabIndex = 4;
            this.lb_det.Text = "Details";
            // 
            // lb_nam
            // 
            this.lb_nam.AutoSize = true;
            this.lb_nam.Location = new System.Drawing.Point(70, 463);
            this.lb_nam.Name = "lb_nam";
            this.lb_nam.Size = new System.Drawing.Size(59, 20);
            this.lb_nam.TabIndex = 5;
            this.lb_nam.Text = "Nama :";
            // 
            // lb_category
            // 
            this.lb_category.AutoSize = true;
            this.lb_category.Location = new System.Drawing.Point(48, 502);
            this.lb_category.Name = "lb_category";
            this.lb_category.Size = new System.Drawing.Size(81, 20);
            this.lb_category.TabIndex = 6;
            this.lb_category.Text = "Category :";
            // 
            // lb_harga
            // 
            this.lb_harga.AutoSize = true;
            this.lb_harga.Location = new System.Drawing.Point(68, 545);
            this.lb_harga.Name = "lb_harga";
            this.lb_harga.Size = new System.Drawing.Size(61, 20);
            this.lb_harga.TabIndex = 7;
            this.lb_harga.Text = "Harga :";
            // 
            // lb_stock
            // 
            this.lb_stock.AutoSize = true;
            this.lb_stock.Location = new System.Drawing.Point(70, 585);
            this.lb_stock.Name = "lb_stock";
            this.lb_stock.Size = new System.Drawing.Size(58, 20);
            this.lb_stock.TabIndex = 8;
            this.lb_stock.Text = "Stock :";
            // 
            // lb_nama
            // 
            this.lb_nama.AutoSize = true;
            this.lb_nama.Location = new System.Drawing.Point(866, 333);
            this.lb_nama.Name = "lb_nama";
            this.lb_nama.Size = new System.Drawing.Size(59, 20);
            this.lb_nama.TabIndex = 9;
            this.lb_nama.Text = "Nama :";
            // 
            // tb_namaprod
            // 
            this.tb_namaprod.Location = new System.Drawing.Point(135, 463);
            this.tb_namaprod.Name = "tb_namaprod";
            this.tb_namaprod.Size = new System.Drawing.Size(504, 26);
            this.tb_namaprod.TabIndex = 10;
            // 
            // tb_harga
            // 
            this.tb_harga.Location = new System.Drawing.Point(135, 539);
            this.tb_harga.Name = "tb_harga";
            this.tb_harga.Size = new System.Drawing.Size(169, 26);
            this.tb_harga.TabIndex = 11;
            this.tb_harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_harga_KeyPress);
            // 
            // tb_stock
            // 
            this.tb_stock.Location = new System.Drawing.Point(135, 582);
            this.tb_stock.Name = "tb_stock";
            this.tb_stock.Size = new System.Drawing.Size(166, 26);
            this.tb_stock.TabIndex = 12;
            this.tb_stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_stock_KeyPress);
            // 
            // tb_namacat
            // 
            this.tb_namacat.Location = new System.Drawing.Point(936, 333);
            this.tb_namacat.Name = "tb_namacat";
            this.tb_namacat.Size = new System.Drawing.Size(276, 26);
            this.tb_namacat.TabIndex = 13;
            // 
            // btn_All
            // 
            this.btn_All.Location = new System.Drawing.Point(344, 31);
            this.btn_All.Name = "btn_All";
            this.btn_All.Size = new System.Drawing.Size(55, 35);
            this.btn_All.TabIndex = 14;
            this.btn_All.Text = "All";
            this.btn_All.UseVisualStyleBackColor = true;
            this.btn_All.Click += new System.EventHandler(this.btn_All_Click);
            // 
            // btn_filter
            // 
            this.btn_filter.Location = new System.Drawing.Point(405, 31);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(67, 35);
            this.btn_filter.TabIndex = 15;
            this.btn_filter.Text = "Filter:";
            this.btn_filter.UseVisualStyleBackColor = true;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // btn_Addprod
            // 
            this.btn_Addprod.BackColor = System.Drawing.Color.Lime;
            this.btn_Addprod.Location = new System.Drawing.Point(354, 525);
            this.btn_Addprod.Name = "btn_Addprod";
            this.btn_Addprod.Size = new System.Drawing.Size(91, 69);
            this.btn_Addprod.TabIndex = 16;
            this.btn_Addprod.Text = "Add Product";
            this.btn_Addprod.UseVisualStyleBackColor = false;
            this.btn_Addprod.Click += new System.EventHandler(this.btn_Addprod_Click);
            // 
            // btn_Editprod
            // 
            this.btn_Editprod.BackColor = System.Drawing.Color.Yellow;
            this.btn_Editprod.Location = new System.Drawing.Point(451, 525);
            this.btn_Editprod.Name = "btn_Editprod";
            this.btn_Editprod.Size = new System.Drawing.Size(91, 69);
            this.btn_Editprod.TabIndex = 17;
            this.btn_Editprod.Text = "Edit Product";
            this.btn_Editprod.UseVisualStyleBackColor = false;
            this.btn_Editprod.Click += new System.EventHandler(this.btn_Editprod_Click);
            // 
            // btn_Removepod
            // 
            this.btn_Removepod.BackColor = System.Drawing.Color.Red;
            this.btn_Removepod.Location = new System.Drawing.Point(548, 525);
            this.btn_Removepod.Name = "btn_Removepod";
            this.btn_Removepod.Size = new System.Drawing.Size(91, 69);
            this.btn_Removepod.TabIndex = 18;
            this.btn_Removepod.Text = "Remove Product";
            this.btn_Removepod.UseVisualStyleBackColor = false;
            this.btn_Removepod.Click += new System.EventHandler(this.btn_RemoveProd_Click);
            // 
            // btn_Addcat
            // 
            this.btn_Addcat.BackColor = System.Drawing.Color.Lime;
            this.btn_Addcat.Location = new System.Drawing.Point(980, 373);
            this.btn_Addcat.Name = "btn_Addcat";
            this.btn_Addcat.Size = new System.Drawing.Size(91, 69);
            this.btn_Addcat.TabIndex = 19;
            this.btn_Addcat.Text = "Add Category";
            this.btn_Addcat.UseVisualStyleBackColor = false;
            this.btn_Addcat.Click += new System.EventHandler(this.btn_Addcat_Click);
            // 
            // btn_Removecat
            // 
            this.btn_Removecat.BackColor = System.Drawing.Color.Red;
            this.btn_Removecat.Location = new System.Drawing.Point(1077, 373);
            this.btn_Removecat.Name = "btn_Removecat";
            this.btn_Removecat.Size = new System.Drawing.Size(91, 69);
            this.btn_Removecat.TabIndex = 20;
            this.btn_Removecat.Text = "Remove Category";
            this.btn_Removecat.UseVisualStyleBackColor = false;
            this.btn_Removecat.Click += new System.EventHandler(this.btn_Removecat_Click);
            // 
            // combo_filter
            // 
            this.combo_filter.FormattingEnabled = true;
            this.combo_filter.Items.AddRange(new object[] {
            "Jas",
            "T-Shirt",
            "Rok",
            "Celana",
            "Cawat"});
            this.combo_filter.Location = new System.Drawing.Point(478, 31);
            this.combo_filter.Name = "combo_filter";
            this.combo_filter.Size = new System.Drawing.Size(161, 28);
            this.combo_filter.TabIndex = 21;
            this.combo_filter.SelectedIndexChanged += new System.EventHandler(this.combo_filter_SelectedIndexChanged);
            // 
            // combo_category
            // 
            this.combo_category.FormattingEnabled = true;
            this.combo_category.Items.AddRange(new object[] {
            "Jas",
            "T-Shirt",
            "Rok",
            "Celana",
            "Cawat"});
            this.combo_category.Location = new System.Drawing.Point(135, 499);
            this.combo_category.Name = "combo_category";
            this.combo_category.Size = new System.Drawing.Size(169, 28);
            this.combo_category.TabIndex = 22;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(936, 463);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(282, 201);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // form_shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(1397, 651);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.combo_category);
            this.Controls.Add(this.combo_filter);
            this.Controls.Add(this.btn_Removecat);
            this.Controls.Add(this.btn_Addcat);
            this.Controls.Add(this.btn_Removepod);
            this.Controls.Add(this.btn_Editprod);
            this.Controls.Add(this.btn_Addprod);
            this.Controls.Add(this.btn_filter);
            this.Controls.Add(this.btn_All);
            this.Controls.Add(this.tb_namacat);
            this.Controls.Add(this.tb_stock);
            this.Controls.Add(this.tb_harga);
            this.Controls.Add(this.tb_namaprod);
            this.Controls.Add(this.lb_nama);
            this.Controls.Add(this.lb_stock);
            this.Controls.Add(this.lb_harga);
            this.Controls.Add(this.lb_category);
            this.Controls.Add(this.lb_nam);
            this.Controls.Add(this.lb_det);
            this.Controls.Add(this.lb_cat);
            this.Controls.Add(this.lb_prod);
            this.Controls.Add(this.dgv_Category);
            this.Controls.Add(this.dgv_Product);
            this.Name = "form_shop";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.form_shop_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Category)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_Product;
        private System.Windows.Forms.DataGridView dgv_Category;
        private System.Windows.Forms.Label lb_prod;
        private System.Windows.Forms.Label lb_cat;
        private System.Windows.Forms.Label lb_det;
        private System.Windows.Forms.Label lb_nam;
        private System.Windows.Forms.Label lb_category;
        private System.Windows.Forms.Label lb_harga;
        private System.Windows.Forms.Label lb_stock;
        private System.Windows.Forms.Label lb_nama;
        private System.Windows.Forms.TextBox tb_namaprod;
        private System.Windows.Forms.TextBox tb_harga;
        private System.Windows.Forms.TextBox tb_stock;
        private System.Windows.Forms.TextBox tb_namacat;
        private System.Windows.Forms.Button btn_All;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.Button btn_Addprod;
        private System.Windows.Forms.Button btn_Editprod;
        private System.Windows.Forms.Button btn_Removepod;
        private System.Windows.Forms.Button btn_Addcat;
        private System.Windows.Forms.Button btn_Removecat;
        private System.Windows.Forms.ComboBox combo_filter;
        private System.Windows.Forms.ComboBox combo_category;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

