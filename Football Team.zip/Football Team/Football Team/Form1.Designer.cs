﻿namespace Football_Team
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_soccerteamlist = new System.Windows.Forms.Label();
            this.lb_Choosecountry = new System.Windows.Forms.Label();
            this.lb_Chooseteam = new System.Windows.Forms.Label();
            this.lb_Addingteam = new System.Windows.Forms.Label();
            this.lb_Teamname = new System.Windows.Forms.Label();
            this.lb_Teamcountry = new System.Windows.Forms.Label();
            this.lb_Teamcity = new System.Windows.Forms.Label();
            this.lb_Addingplayers = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tb_Name = new System.Windows.Forms.TextBox();
            this.tb_Country = new System.Windows.Forms.TextBox();
            this.tb_City = new System.Windows.Forms.TextBox();
            this.tb_Playername = new System.Windows.Forms.TextBox();
            this.tb_Number = new System.Windows.Forms.TextBox();
            this.combo_country = new System.Windows.Forms.ComboBox();
            this.combo_Team = new System.Windows.Forms.ComboBox();
            this.combo_Position = new System.Windows.Forms.ComboBox();
            this.list_player = new System.Windows.Forms.ListBox();
            this.btn_Remove = new System.Windows.Forms.Button();
            this.btn_Addteam = new System.Windows.Forms.Button();
            this.btn_Addplayers = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_soccerteamlist
            // 
            this.lb_soccerteamlist.AutoSize = true;
            this.lb_soccerteamlist.Location = new System.Drawing.Point(12, 29);
            this.lb_soccerteamlist.Name = "lb_soccerteamlist";
            this.lb_soccerteamlist.Size = new System.Drawing.Size(136, 20);
            this.lb_soccerteamlist.TabIndex = 0;
            this.lb_soccerteamlist.Text = "Soccer Team List:";
            // 
            // lb_Choosecountry
            // 
            this.lb_Choosecountry.AutoSize = true;
            this.lb_Choosecountry.Location = new System.Drawing.Point(12, 90);
            this.lb_Choosecountry.Name = "lb_Choosecountry";
            this.lb_Choosecountry.Size = new System.Drawing.Size(127, 20);
            this.lb_Choosecountry.TabIndex = 1;
            this.lb_Choosecountry.Text = "Choose Country:";
            // 
            // lb_Chooseteam
            // 
            this.lb_Chooseteam.AutoSize = true;
            this.lb_Chooseteam.Location = new System.Drawing.Point(12, 157);
            this.lb_Chooseteam.Name = "lb_Chooseteam";
            this.lb_Chooseteam.Size = new System.Drawing.Size(112, 20);
            this.lb_Chooseteam.TabIndex = 2;
            this.lb_Chooseteam.Text = "Choose Team:";
            // 
            // lb_Addingteam
            // 
            this.lb_Addingteam.AutoSize = true;
            this.lb_Addingteam.Location = new System.Drawing.Point(439, 29);
            this.lb_Addingteam.Name = "lb_Addingteam";
            this.lb_Addingteam.Size = new System.Drawing.Size(107, 20);
            this.lb_Addingteam.TabIndex = 3;
            this.lb_Addingteam.Text = "Adding Team:";
            // 
            // lb_Teamname
            // 
            this.lb_Teamname.AutoSize = true;
            this.lb_Teamname.Location = new System.Drawing.Point(350, 90);
            this.lb_Teamname.Name = "lb_Teamname";
            this.lb_Teamname.Size = new System.Drawing.Size(99, 20);
            this.lb_Teamname.TabIndex = 4;
            this.lb_Teamname.Text = "Team Name:";
            // 
            // lb_Teamcountry
            // 
            this.lb_Teamcountry.AutoSize = true;
            this.lb_Teamcountry.Location = new System.Drawing.Point(350, 143);
            this.lb_Teamcountry.Name = "lb_Teamcountry";
            this.lb_Teamcountry.Size = new System.Drawing.Size(112, 20);
            this.lb_Teamcountry.TabIndex = 5;
            this.lb_Teamcountry.Text = "Team Country:";
            // 
            // lb_Teamcity
            // 
            this.lb_Teamcity.AutoSize = true;
            this.lb_Teamcity.Location = new System.Drawing.Point(350, 201);
            this.lb_Teamcity.Name = "lb_Teamcity";
            this.lb_Teamcity.Size = new System.Drawing.Size(83, 20);
            this.lb_Teamcity.TabIndex = 6;
            this.lb_Teamcity.Text = "Team City:";
            // 
            // lb_Addingplayers
            // 
            this.lb_Addingplayers.AutoSize = true;
            this.lb_Addingplayers.Location = new System.Drawing.Point(805, 29);
            this.lb_Addingplayers.Name = "lb_Addingplayers";
            this.lb_Addingplayers.Size = new System.Drawing.Size(118, 20);
            this.lb_Addingplayers.TabIndex = 7;
            this.lb_Addingplayers.Text = "Adding Players:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(689, 93);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(102, 20);
            this.label9.TabIndex = 8;
            this.label9.Text = "Player Name:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(689, 146);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(116, 20);
            this.label10.TabIndex = 9;
            this.label10.Text = "Player Number:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(689, 200);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(116, 20);
            this.label11.TabIndex = 10;
            this.label11.Text = "Player Position:";
            // 
            // tb_Name
            // 
            this.tb_Name.Location = new System.Drawing.Point(468, 84);
            this.tb_Name.Name = "tb_Name";
            this.tb_Name.Size = new System.Drawing.Size(169, 26);
            this.tb_Name.TabIndex = 11;
            // 
            // tb_Country
            // 
            this.tb_Country.Location = new System.Drawing.Point(468, 143);
            this.tb_Country.Name = "tb_Country";
            this.tb_Country.Size = new System.Drawing.Size(169, 26);
            this.tb_Country.TabIndex = 12;
            // 
            // tb_City
            // 
            this.tb_City.Location = new System.Drawing.Point(468, 200);
            this.tb_City.Name = "tb_City";
            this.tb_City.Size = new System.Drawing.Size(169, 26);
            this.tb_City.TabIndex = 13;
            // 
            // tb_Playername
            // 
            this.tb_Playername.Location = new System.Drawing.Point(809, 87);
            this.tb_Playername.Name = "tb_Playername";
            this.tb_Playername.Size = new System.Drawing.Size(167, 26);
            this.tb_Playername.TabIndex = 14;
            // 
            // tb_Number
            // 
            this.tb_Number.Location = new System.Drawing.Point(811, 143);
            this.tb_Number.Name = "tb_Number";
            this.tb_Number.Size = new System.Drawing.Size(167, 26);
            this.tb_Number.TabIndex = 15;
            // 
            // combo_country
            // 
            this.combo_country.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_country.FormattingEnabled = true;
            this.combo_country.Items.AddRange(new object[] {
            "Spain",
            "Germany"});
            this.combo_country.Location = new System.Drawing.Point(145, 90);
            this.combo_country.Name = "combo_country";
            this.combo_country.Size = new System.Drawing.Size(162, 28);
            this.combo_country.TabIndex = 16;
            this.combo_country.DropDown += new System.EventHandler(this.combo_country_SelectedIndexChanged);
            this.combo_country.SelectedIndexChanged += new System.EventHandler(this.combo_country_SelectedIndexChanged);
            // 
            // combo_Team
            // 
            this.combo_Team.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Team.FormattingEnabled = true;
            this.combo_Team.Location = new System.Drawing.Point(145, 154);
            this.combo_Team.Name = "combo_Team";
            this.combo_Team.Size = new System.Drawing.Size(162, 28);
            this.combo_Team.TabIndex = 17;
            this.combo_Team.SelectedIndexChanged += new System.EventHandler(this.combo_Team_SelectedIndexChanged);
            // 
            // combo_Position
            // 
            this.combo_Position.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Position.FormattingEnabled = true;
            this.combo_Position.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.combo_Position.Location = new System.Drawing.Point(811, 201);
            this.combo_Position.Name = "combo_Position";
            this.combo_Position.Size = new System.Drawing.Size(165, 28);
            this.combo_Position.TabIndex = 18;
            // 
            // list_player
            // 
            this.list_player.FormattingEnabled = true;
            this.list_player.ItemHeight = 20;
            this.list_player.Location = new System.Drawing.Point(16, 228);
            this.list_player.Name = "list_player";
            this.list_player.Size = new System.Drawing.Size(291, 164);
            this.list_player.TabIndex = 19;
            // 
            // btn_Remove
            // 
            this.btn_Remove.Location = new System.Drawing.Point(16, 398);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(84, 31);
            this.btn_Remove.TabIndex = 20;
            this.btn_Remove.Text = "Remove";
            this.btn_Remove.UseVisualStyleBackColor = true;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // btn_Addteam
            // 
            this.btn_Addteam.Location = new System.Drawing.Point(468, 251);
            this.btn_Addteam.Name = "btn_Addteam";
            this.btn_Addteam.Size = new System.Drawing.Size(63, 36);
            this.btn_Addteam.TabIndex = 21;
            this.btn_Addteam.Text = "Add";
            this.btn_Addteam.UseVisualStyleBackColor = true;
            this.btn_Addteam.Click += new System.EventHandler(this.btn_Addteam_Click);
            // 
            // btn_Addplayers
            // 
            this.btn_Addplayers.Location = new System.Drawing.Point(809, 251);
            this.btn_Addplayers.Name = "btn_Addplayers";
            this.btn_Addplayers.Size = new System.Drawing.Size(67, 36);
            this.btn_Addplayers.TabIndex = 22;
            this.btn_Addplayers.Text = "Add";
            this.btn_Addplayers.UseVisualStyleBackColor = true;
            this.btn_Addplayers.Click += new System.EventHandler(this.btn_Addplayers_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1072, 496);
            this.Controls.Add(this.btn_Addplayers);
            this.Controls.Add(this.btn_Addteam);
            this.Controls.Add(this.btn_Remove);
            this.Controls.Add(this.list_player);
            this.Controls.Add(this.combo_Position);
            this.Controls.Add(this.combo_Team);
            this.Controls.Add(this.combo_country);
            this.Controls.Add(this.tb_Number);
            this.Controls.Add(this.tb_Playername);
            this.Controls.Add(this.tb_City);
            this.Controls.Add(this.tb_Country);
            this.Controls.Add(this.tb_Name);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lb_Addingplayers);
            this.Controls.Add(this.lb_Teamcity);
            this.Controls.Add(this.lb_Teamcountry);
            this.Controls.Add(this.lb_Teamname);
            this.Controls.Add(this.lb_Addingteam);
            this.Controls.Add(this.lb_Chooseteam);
            this.Controls.Add(this.lb_Choosecountry);
            this.Controls.Add(this.lb_soccerteamlist);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_soccerteamlist;
        private System.Windows.Forms.Label lb_Choosecountry;
        private System.Windows.Forms.Label lb_Chooseteam;
        private System.Windows.Forms.Label lb_Addingteam;
        private System.Windows.Forms.Label lb_Teamname;
        private System.Windows.Forms.Label lb_Teamcountry;
        private System.Windows.Forms.Label lb_Teamcity;
        private System.Windows.Forms.Label lb_Addingplayers;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tb_Name;
        private System.Windows.Forms.TextBox tb_Country;
        private System.Windows.Forms.TextBox tb_City;
        private System.Windows.Forms.TextBox tb_Playername;
        private System.Windows.Forms.TextBox tb_Number;
        private System.Windows.Forms.ComboBox combo_country;
        private System.Windows.Forms.ComboBox combo_Team;
        private System.Windows.Forms.ComboBox combo_Position;
        private System.Windows.Forms.ListBox list_player;
        private System.Windows.Forms.Button btn_Remove;
        private System.Windows.Forms.Button btn_Addteam;
        private System.Windows.Forms.Button btn_Addplayers;
    }
}

