﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Football_Team
{
    public class Team
    {
        public string teamName {  get; set; }
        public string teamCountry { get; set; }
        public string teamCity { get; set; }
        public List<Player> Players { get; set; }

        public Team(string teamName, string teamCountry, string teamCity)
        {
            this.teamName = teamName;
            this.teamCountry = teamCountry;
            this.teamCity = teamCity;
            Players = new List<Player>();
        }

        public void AddPlayer(string PlayerName,string PlayerNum,string PlayerPos)
        {
            Players.Add(new Player(PlayerName,PlayerNum,PlayerPos));
        }
    }

    public class Player
    {
        public string PlayerName { get; set; }
        public string PlayerNum { get; set; }
        public string PlayerPos { get; set; }

        public Player(string Playername, string PlayerNum, string PlayerPos)
        {
            this.PlayerName = Playername;
            this.PlayerNum = PlayerNum;
            this.PlayerPos = PlayerPos;
        }
    }

}
