﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Football_Team
{
    public partial class Form1 : Form
    {
        List<Team> team = new List<Team>();
        List<string> country;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
           
            Team teams = new Team("Barcelona", "Spain","Barcelona");
            teams.AddPlayer("ter Stegen", "01", "GK");
            teams.AddPlayer("Alejandro Balde", "03", "DF");
            teams.AddPlayer("Ronald Araujo", "04", "DF");
            teams.AddPlayer("Andreas Christensen", "15", "DF");
            teams.AddPlayer("Jules Kounde", "23", "DF");
            teams.AddPlayer("Gavi", "06", "MF");
            teams.AddPlayer("Pedri", "08", "MF");
            teams.AddPlayer("Frenkie de Jong", "21", "MF");
            teams.AddPlayer("Ferran Torres", "07", "FW");
            teams.AddPlayer("Robert Lewandowski", "09", "FW");
            teams.AddPlayer("Raphinha", "11", "FW");
            team.Add(teams);

            Team teamss = new Team("Real Madrid", "Spain", "Madrid");
            teamss.AddPlayer("Thibaut Courtois", "01", "GK");
            teamss.AddPlayer("Carvajal", "02", "DF");
            teamss.AddPlayer("Alaba", "04", "DF");
            teamss.AddPlayer("Rudiger", "22", "DF");
            teamss.AddPlayer("E.Militao", "03", "DF");
            teamss.AddPlayer("Jude Bellingham", "05", "MF");
            teamss.AddPlayer("Camavinga", "12", "MF");
            teamss.AddPlayer("Valverde", "15", "MF");
            teamss.AddPlayer("Tchouameni", "18", "MF");
            teamss.AddPlayer("Vini Jr.", "07", "FW");
            teamss.AddPlayer("Rodrygo", "11", "FW");
            team.Add(teamss);

            Team teamsss = new Team("Bayern Munich", "Germany", "Munich");
            teamsss.AddPlayer("Manuel Neuer", "01", "GK");
            teamsss.AddPlayer("D.Upamecano", "02", "DF");
            teamsss.AddPlayer("Kim Minjae", "03", "DF");
            teamsss.AddPlayer("Matthijs de Ligt", "04", "DF");
            teamsss.AddPlayer("Alphonso Davies", "19", "DF");
            teamsss.AddPlayer("Joshua Kimmich", "06", "MF");
            teamsss.AddPlayer("Leon Goretzka", "08", "MF");
            teamsss.AddPlayer("Jamal Musiala", "42", "MF");
            teamsss.AddPlayer("Serge Gnabry", "07", "FW");
            teamsss.AddPlayer("Harry Kane", "09", "FW");
            teamsss.AddPlayer("Leroy Sane", "10", "FW");
            team.Add(teamsss);

        }
        private void combo_country_SelectedIndexChanged(object sender, EventArgs e)
        {
            combo_Team.Items.Clear();
            string selectedCountry = combo_country.SelectedItem as string;
            if (selectedCountry != null)
            {
                foreach (Team t in team)
                {
                    if (t.teamCountry == combo_country.SelectedItem.ToString())
                    {
                        combo_Team.Items.Add(t.teamName);
                    }
                }
            }
           
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            int selectedIndex = list_player.SelectedIndex;
            if (selectedIndex == -1)
            {
                MessageBox.Show("Please select a player to remove.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Team selectedTeam = null;
            foreach (Team t in team)
            {
                if (t.teamName == combo_Team.SelectedItem.ToString())
                {
                    selectedTeam = t;
                    break;
                }
            }

            if (selectedTeam == null)
            {
                MessageBox.Show("No team selected.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (selectedTeam.Players.Count <= 11)
            {
                MessageBox.Show("Unable to remove players if there are 11 or fewer players in the team.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            selectedTeam.Players.RemoveAt(selectedIndex);
            list_player.Items.RemoveAt(selectedIndex);
        }

        private void combo_Team_SelectedIndexChanged(object sender, EventArgs e)
        {
            list_player.Items.Clear();
            foreach (Team t in team)
            {
                if(t.teamName == combo_Team.SelectedItem.ToString())
                {
                    foreach(Player player in t.Players)
                    {
                        list_player.Items.Add($"({player.PlayerNum}) {player.PlayerName}, {player.PlayerPos}");
                    }
                }
            }
        }

        private void btn_Addteam_Click(object sender, EventArgs e)
        {
            bool ada = false;
            foreach(Team t in team)
            {
                if (t.teamName == tb_Name.Text)
                {
                    ada = true;
                    break;
                }
            }

            if (tb_Name.Text == "" || tb_Country.Text == "" || tb_City.Text == "")
            {
                MessageBox.Show("All Fields Needs to be Filled", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (ada == true)
            {
                ada = false;
                MessageBox.Show("Team with the same name already exists", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Team teamchange = new Team(tb_Name.Text, tb_Country.Text, tb_City.Text);
                team.Add(teamchange);

                foreach(Team c in team)
                {
                    if (!combo_country.Items.Contains(c.teamCountry))
                    {
                        combo_country.Items.Add(c.teamCountry);
                    }
                }
                foreach(Team t in team)
                {
                    if(!combo_Team.Items.Contains(t.teamName) && (t.teamCountry == combo_country.Text))
                    {
                        combo_Team.Items.Add(t.teamName);
                    }
                }
                tb_Name.Text = "";
                tb_Country.Text = "";
                tb_City.Text = "";

            }
        }

        private void btn_Addplayers_Click(object sender, EventArgs e)
        {
            if (tb_Playername.Text == "" || tb_Number.Text == "" || combo_Position.SelectedItem == null)
            {
                MessageBox.Show("All Fields Need to be Filled", "Error",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (combo_Team.SelectedItem == null)
            {
                MessageBox.Show("Please select a team", "Error",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string selectedTeamName = combo_Team.SelectedItem.ToString();
            Team selectedTeam = null;

            foreach (Team t in team)
            {
                if (t.teamName == selectedTeamName)
                {
                    selectedTeam = t;
                    break;
                }
            }

            if (selectedTeam != null)
            {
                bool playerExists = false;

                foreach (Player p in selectedTeam.Players)
                {
                    if (p.PlayerName == tb_Playername.Text)
                    {
                        playerExists = true;
                        break;
                    }
                    if (p.PlayerNum == tb_Number.Text)
                    {
                        playerExists = true;
                        break;
                    }
                }

                if (playerExists)
                {
                    MessageBox.Show("Player with the same name/number already exists in the selected team", "Error",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    string position = (string)combo_Position.SelectedItem;
                    Player newPlayer = new Player(tb_Playername.Text, tb_Number.Text, position);
                    selectedTeam.Players.Add(newPlayer);

                    list_player.Items.Clear();
                    foreach (Player player in selectedTeam.Players)
                    {
                        list_player.Items.Add($"({player.PlayerNum}) {player.PlayerName}, {player.PlayerPos}");
                    }

                    tb_Playername.Text = "";
                    tb_Number.Text = "";
                    combo_Position.SelectedIndex = -1;
                }
            }
            else
            {
                MessageBox.Show("Selected team not found", "Error",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
           
        }
    }
}
