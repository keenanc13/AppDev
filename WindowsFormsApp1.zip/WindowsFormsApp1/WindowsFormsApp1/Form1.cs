﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_play_Click(object sender, EventArgs e)
        {
            List <string> words = new List<string>();
            words.Add(tb_kata1.Text);
            words.Add(tb_kata2.Text);
            words.Add(tb_kata3.Text);
            words.Add(tb_kata4.Text);
            words.Add(tb_kata5.Text);

            bool limaHuruf = false;
            for (int i = 0; i < words.Count; i++)
            {
                if (words[i].Length != 5)
                {
                    limaHuruf = true;
                }
            }
            bool salah = false;
            for (int i = 0; i < words.Count - 1; i++)
            {
                for (int j = i+1; j < words.Count; j++)
                {
                    if (words[i] == words[j])
                    {
                        salah = true;
                    }
                }
            }
            bool adanomor = false;
            foreach(string word in words)
            {
                foreach (char c in word)
                {
                    if (!char.IsLetter(c))
                    {
                        adanomor = true;
                    }
                }
            }
            if (limaHuruf)
            {
                MessageBox.Show("Error,harus 5 kata");
            }
            else if (adanomor)
            {
                MessageBox.Show("Error,terdapat angka di huruf");
            }
            else if (salah)
            {
                MessageBox.Show("Error,ada yang sama");
            }
            else 
            {
                Random rnd = new Random();
                int num = rnd.Next(0,5);
                string terserah = words[num];
                FormMain form = new FormMain(terserah);
                form.guess = terserah;
                form.Show();
                this.Hide();
                
            }
            


        }
    }
}
