﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Tracing;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FormMain : Form
    {
        public string guess;
        public FormMain(string terserah)
        {
            InitializeComponent();
        }

        private void btn_Q_Click(object sender, EventArgs e)
        {
            cek('q');
        }

        private void btn_W_Click(object sender, EventArgs e)
        {
            cek('w');
        }

        private void btn_E_Click(object sender, EventArgs e)
        {
            cek('e');
        }

        private void btn_R_Click(object sender, EventArgs e)
        {
            cek('r');
        }

        private void btn_T_Click(object sender, EventArgs e)
        {
            cek('t');
        }

        private void btn_Y_Click(object sender, EventArgs e)
        {
            cek('y');
        }

        private void btn_U_Click(object sender, EventArgs e)
        {
            cek('u');
        }

        private void btn_I_Click(object sender, EventArgs e)
        {
            cek('i');
        }

        private void btn_O_Click(object sender, EventArgs e)
        {
            cek('o');
        }

        private void btn_P_Click(object sender, EventArgs e)
        {
            cek('p');
        }

        private void btn_A_Click(object sender, EventArgs e)
        {
            cek('a');
        }

        private void btn_S_Click(object sender, EventArgs e)
        {
            cek('s');
        }

        private void btn_D_Click(object sender, EventArgs e)
        {
            cek('d');
        }

        private void btn_F_Click(object sender, EventArgs e)
        {
            cek('f');
        }

        private void btn_G_Click(object sender, EventArgs e)
        {
            cek('g');
        }

        private void btn_H_Click(object sender, EventArgs e)
        {
            cek('h');
        }

        private void btn_J_Click(object sender, EventArgs e)
        {
            cek('j');
        }

        private void btn_K_Click(object sender, EventArgs e)
        {
            cek('k');
        }

        private void btn_L_Click(object sender, EventArgs e)
        {
            cek('l');
        }

        private void btn_Z_Click(object sender, EventArgs e)
        {
            cek('z');
        }

        private void btn_X_Click(object sender, EventArgs e)
        {
            cek('x');
        }

        private void btn_C_Click(object sender, EventArgs e)
        {
            cek('c');
        }

        private void btn_V_Click(object sender, EventArgs e)
        {
            cek('v');
        }

        private void btn_B_Click(object sender, EventArgs e)
        {
            cek('b');
        }

        private void btn_N_Click(object sender, EventArgs e)
        {
            cek('n');
        }

        private void btn_M_Click(object sender, EventArgs e)
        {
            cek('m');
        }

        private void cek(char x)
        {
            for (int i = 0; i < 5; i++)
            {
                if (guess[i] == x)
                {
                    if (i == 0)
                    {
                        lb_index0.Text = x.ToString();
                    }
                    if (i == 1)
                    {
                        lb_index1.Text = x.ToString();
                    }
                    if (i == 2)
                    {
                        lb_index2.Text = x.ToString();
                    }
                    if(i == 3)
                    {
                        lb_index3.Text = x.ToString();
                    }
                    if(i == 4)
                    {
                        lb_index4.Text = x.ToString();
                    }
                    
                }
            }
            hasilGame();
        }

        private void hasilGame()
        {
            string sisa = "";
            sisa = lb_index0.Text + lb_index1.Text + lb_index2.Text + lb_index3.Text + lb_index4.Text;
            if (sisa == guess)
            {
                MessageBox.Show("YUHUUUU");
            }
        }
    }
}
