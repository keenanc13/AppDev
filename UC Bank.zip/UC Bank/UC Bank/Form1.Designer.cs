﻿namespace UC_Bank
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pan_login = new System.Windows.Forms.Panel();
            this.btn_Register = new System.Windows.Forms.Button();
            this.btn_Login = new System.Windows.Forms.Button();
            this.tb_pass = new System.Windows.Forms.TextBox();
            this.tb_user = new System.Windows.Forms.TextBox();
            this.lb_Pass = new System.Windows.Forms.Label();
            this.lb_User = new System.Windows.Forms.Label();
            this.lb_ucbank = new System.Windows.Forms.Label();
            this.pan_regis = new System.Windows.Forms.Panel();
            this.tb_passreg = new System.Windows.Forms.TextBox();
            this.tb_userreg = new System.Windows.Forms.TextBox();
            this.lb_pass2 = new System.Windows.Forms.Label();
            this.lb_user2 = new System.Windows.Forms.Label();
            this.lb_uc = new System.Windows.Forms.Label();
            this.btn_reg = new System.Windows.Forms.Button();
            this.pan_balance = new System.Windows.Forms.Panel();
            this.lb_number = new System.Windows.Forms.Label();
            this.btn_logout = new System.Windows.Forms.Button();
            this.btn_withdraw = new System.Windows.Forms.Button();
            this.btn_deposit = new System.Windows.Forms.Button();
            this.lb_rp = new System.Windows.Forms.Label();
            this.lb_balance = new System.Windows.Forms.Label();
            this.lb_ucbalance = new System.Windows.Forms.Label();
            this.pan_depo = new System.Windows.Forms.Panel();
            this.tb_Jumlahdepo = new System.Windows.Forms.TextBox();
            this.btn_logoutdeposit = new System.Windows.Forms.Button();
            this.btn_Jumlahdepo = new System.Windows.Forms.Button();
            this.lb_Amount = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pan_with = new System.Windows.Forms.Panel();
            this.lb_numberwith = new System.Windows.Forms.Label();
            this.lb_Rpwith = new System.Windows.Forms.Label();
            this.lb_balancewith = new System.Windows.Forms.Label();
            this.tb_Jumlahwith = new System.Windows.Forms.TextBox();
            this.btn_logoutwith = new System.Windows.Forms.Button();
            this.btn_Jumlahwith = new System.Windows.Forms.Button();
            this.lb_withamount = new System.Windows.Forms.Label();
            this.lb_ucbankwith = new System.Windows.Forms.Label();
            this.pan_login.SuspendLayout();
            this.pan_regis.SuspendLayout();
            this.pan_balance.SuspendLayout();
            this.pan_depo.SuspendLayout();
            this.pan_with.SuspendLayout();
            this.SuspendLayout();
            // 
            // pan_login
            // 
            this.pan_login.Controls.Add(this.btn_Register);
            this.pan_login.Controls.Add(this.btn_Login);
            this.pan_login.Controls.Add(this.tb_pass);
            this.pan_login.Controls.Add(this.tb_user);
            this.pan_login.Controls.Add(this.lb_Pass);
            this.pan_login.Controls.Add(this.lb_User);
            this.pan_login.Controls.Add(this.lb_ucbank);
            this.pan_login.Location = new System.Drawing.Point(382, 12);
            this.pan_login.Name = "pan_login";
            this.pan_login.Size = new System.Drawing.Size(306, 238);
            this.pan_login.TabIndex = 0;
            // 
            // btn_Register
            // 
            this.btn_Register.Location = new System.Drawing.Point(101, 187);
            this.btn_Register.Name = "btn_Register";
            this.btn_Register.Size = new System.Drawing.Size(86, 34);
            this.btn_Register.TabIndex = 6;
            this.btn_Register.Text = "Register";
            this.btn_Register.UseVisualStyleBackColor = true;
            this.btn_Register.Click += new System.EventHandler(this.btn_Register_Click);
            // 
            // btn_Login
            // 
            this.btn_Login.Location = new System.Drawing.Point(101, 145);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(84, 36);
            this.btn_Login.TabIndex = 5;
            this.btn_Login.Text = "Login";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            // 
            // tb_pass
            // 
            this.tb_pass.Location = new System.Drawing.Point(140, 105);
            this.tb_pass.Name = "tb_pass";
            this.tb_pass.Size = new System.Drawing.Size(142, 26);
            this.tb_pass.TabIndex = 4;
            // 
            // tb_user
            // 
            this.tb_user.Location = new System.Drawing.Point(140, 73);
            this.tb_user.Name = "tb_user";
            this.tb_user.Size = new System.Drawing.Size(142, 26);
            this.tb_user.TabIndex = 3;
            // 
            // lb_Pass
            // 
            this.lb_Pass.AutoSize = true;
            this.lb_Pass.Location = new System.Drawing.Point(31, 103);
            this.lb_Pass.Name = "lb_Pass";
            this.lb_Pass.Size = new System.Drawing.Size(82, 20);
            this.lb_Pass.TabIndex = 2;
            this.lb_Pass.Text = "Password:";
            // 
            // lb_User
            // 
            this.lb_User.AutoSize = true;
            this.lb_User.Location = new System.Drawing.Point(31, 73);
            this.lb_User.Name = "lb_User";
            this.lb_User.Size = new System.Drawing.Size(87, 20);
            this.lb_User.TabIndex = 1;
            this.lb_User.Text = "Username:";
            // 
            // lb_ucbank
            // 
            this.lb_ucbank.AutoSize = true;
            this.lb_ucbank.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucbank.Location = new System.Drawing.Point(89, 20);
            this.lb_ucbank.Name = "lb_ucbank";
            this.lb_ucbank.Size = new System.Drawing.Size(98, 25);
            this.lb_ucbank.TabIndex = 0;
            this.lb_ucbank.Text = "UC Bank";
            // 
            // pan_regis
            // 
            this.pan_regis.Controls.Add(this.tb_passreg);
            this.pan_regis.Controls.Add(this.tb_userreg);
            this.pan_regis.Controls.Add(this.lb_pass2);
            this.pan_regis.Controls.Add(this.lb_user2);
            this.pan_regis.Controls.Add(this.lb_uc);
            this.pan_regis.Controls.Add(this.btn_reg);
            this.pan_regis.Location = new System.Drawing.Point(28, 18);
            this.pan_regis.Name = "pan_regis";
            this.pan_regis.Size = new System.Drawing.Size(306, 238);
            this.pan_regis.TabIndex = 7;
            this.pan_regis.Visible = false;
            // 
            // tb_passreg
            // 
            this.tb_passreg.Location = new System.Drawing.Point(140, 105);
            this.tb_passreg.Name = "tb_passreg";
            this.tb_passreg.Size = new System.Drawing.Size(142, 26);
            this.tb_passreg.TabIndex = 4;
            // 
            // tb_userreg
            // 
            this.tb_userreg.Location = new System.Drawing.Point(140, 73);
            this.tb_userreg.Name = "tb_userreg";
            this.tb_userreg.Size = new System.Drawing.Size(142, 26);
            this.tb_userreg.TabIndex = 3;
            // 
            // lb_pass2
            // 
            this.lb_pass2.AutoSize = true;
            this.lb_pass2.Location = new System.Drawing.Point(31, 103);
            this.lb_pass2.Name = "lb_pass2";
            this.lb_pass2.Size = new System.Drawing.Size(82, 20);
            this.lb_pass2.TabIndex = 2;
            this.lb_pass2.Text = "Password:";
            // 
            // lb_user2
            // 
            this.lb_user2.AutoSize = true;
            this.lb_user2.Location = new System.Drawing.Point(31, 73);
            this.lb_user2.Name = "lb_user2";
            this.lb_user2.Size = new System.Drawing.Size(87, 20);
            this.lb_user2.TabIndex = 1;
            this.lb_user2.Text = "Username:";
            // 
            // lb_uc
            // 
            this.lb_uc.AutoSize = true;
            this.lb_uc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_uc.Location = new System.Drawing.Point(89, 20);
            this.lb_uc.Name = "lb_uc";
            this.lb_uc.Size = new System.Drawing.Size(98, 25);
            this.lb_uc.TabIndex = 0;
            this.lb_uc.Text = "UC Bank";
            // 
            // btn_reg
            // 
            this.btn_reg.Location = new System.Drawing.Point(101, 149);
            this.btn_reg.Name = "btn_reg";
            this.btn_reg.Size = new System.Drawing.Size(86, 34);
            this.btn_reg.TabIndex = 6;
            this.btn_reg.Text = "Register";
            this.btn_reg.UseVisualStyleBackColor = true;
            this.btn_reg.Click += new System.EventHandler(this.btn_reg_Click);
            // 
            // pan_balance
            // 
            this.pan_balance.Controls.Add(this.lb_number);
            this.pan_balance.Controls.Add(this.btn_logout);
            this.pan_balance.Controls.Add(this.btn_withdraw);
            this.pan_balance.Controls.Add(this.btn_deposit);
            this.pan_balance.Controls.Add(this.lb_rp);
            this.pan_balance.Controls.Add(this.lb_balance);
            this.pan_balance.Controls.Add(this.lb_ucbalance);
            this.pan_balance.Location = new System.Drawing.Point(719, 18);
            this.pan_balance.Name = "pan_balance";
            this.pan_balance.Size = new System.Drawing.Size(306, 238);
            this.pan_balance.TabIndex = 7;
            this.pan_balance.Visible = false;
            // 
            // lb_number
            // 
            this.lb_number.AutoSize = true;
            this.lb_number.Location = new System.Drawing.Point(131, 106);
            this.lb_number.Name = "lb_number";
            this.lb_number.Size = new System.Drawing.Size(44, 20);
            this.lb_number.TabIndex = 8;
            this.lb_number.Text = " 0,00";
            // 
            // btn_logout
            // 
            this.btn_logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logout.Location = new System.Drawing.Point(209, 46);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(83, 36);
            this.btn_logout.TabIndex = 7;
            this.btn_logout.Text = "Log Out";
            this.btn_logout.UseVisualStyleBackColor = true;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // btn_withdraw
            // 
            this.btn_withdraw.Location = new System.Drawing.Point(94, 187);
            this.btn_withdraw.Name = "btn_withdraw";
            this.btn_withdraw.Size = new System.Drawing.Size(100, 34);
            this.btn_withdraw.TabIndex = 6;
            this.btn_withdraw.Text = "Withdraw";
            this.btn_withdraw.UseVisualStyleBackColor = true;
            this.btn_withdraw.Click += new System.EventHandler(this.btn_withdraw_Click);
            // 
            // btn_deposit
            // 
            this.btn_deposit.Location = new System.Drawing.Point(94, 145);
            this.btn_deposit.Name = "btn_deposit";
            this.btn_deposit.Size = new System.Drawing.Size(100, 36);
            this.btn_deposit.TabIndex = 5;
            this.btn_deposit.Text = "Deposit";
            this.btn_deposit.UseVisualStyleBackColor = true;
            this.btn_deposit.Click += new System.EventHandler(this.btn_deposit_Click);
            // 
            // lb_rp
            // 
            this.lb_rp.AutoSize = true;
            this.lb_rp.Location = new System.Drawing.Point(105, 106);
            this.lb_rp.Name = "lb_rp";
            this.lb_rp.Size = new System.Drawing.Size(30, 20);
            this.lb_rp.TabIndex = 2;
            this.lb_rp.Text = "Rp";
            // 
            // lb_balance
            // 
            this.lb_balance.AutoSize = true;
            this.lb_balance.Location = new System.Drawing.Point(28, 106);
            this.lb_balance.Name = "lb_balance";
            this.lb_balance.Size = new System.Drawing.Size(71, 20);
            this.lb_balance.TabIndex = 1;
            this.lb_balance.Text = "Balance:";
            // 
            // lb_ucbalance
            // 
            this.lb_ucbalance.AutoSize = true;
            this.lb_ucbalance.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucbalance.Location = new System.Drawing.Point(89, 20);
            this.lb_ucbalance.Name = "lb_ucbalance";
            this.lb_ucbalance.Size = new System.Drawing.Size(98, 25);
            this.lb_ucbalance.TabIndex = 0;
            this.lb_ucbalance.Text = "UC Bank";
            // 
            // pan_depo
            // 
            this.pan_depo.Controls.Add(this.tb_Jumlahdepo);
            this.pan_depo.Controls.Add(this.btn_logoutdeposit);
            this.pan_depo.Controls.Add(this.btn_Jumlahdepo);
            this.pan_depo.Controls.Add(this.lb_Amount);
            this.pan_depo.Controls.Add(this.label4);
            this.pan_depo.Location = new System.Drawing.Point(28, 281);
            this.pan_depo.Name = "pan_depo";
            this.pan_depo.Size = new System.Drawing.Size(306, 238);
            this.pan_depo.TabIndex = 9;
            this.pan_depo.Visible = false;
            // 
            // tb_Jumlahdepo
            // 
            this.tb_Jumlahdepo.Location = new System.Drawing.Point(73, 125);
            this.tb_Jumlahdepo.Name = "tb_Jumlahdepo";
            this.tb_Jumlahdepo.Size = new System.Drawing.Size(142, 26);
            this.tb_Jumlahdepo.TabIndex = 7;
            // 
            // btn_logoutdeposit
            // 
            this.btn_logoutdeposit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logoutdeposit.Location = new System.Drawing.Point(193, 44);
            this.btn_logoutdeposit.Name = "btn_logoutdeposit";
            this.btn_logoutdeposit.Size = new System.Drawing.Size(94, 30);
            this.btn_logoutdeposit.TabIndex = 7;
            this.btn_logoutdeposit.Text = "Log Out";
            this.btn_logoutdeposit.UseVisualStyleBackColor = true;
            this.btn_logoutdeposit.Click += new System.EventHandler(this.btn_logoutdeposit_Click);
            // 
            // btn_Jumlahdepo
            // 
            this.btn_Jumlahdepo.Location = new System.Drawing.Point(103, 165);
            this.btn_Jumlahdepo.Name = "btn_Jumlahdepo";
            this.btn_Jumlahdepo.Size = new System.Drawing.Size(84, 36);
            this.btn_Jumlahdepo.TabIndex = 5;
            this.btn_Jumlahdepo.Text = "Deposit";
            this.btn_Jumlahdepo.UseVisualStyleBackColor = true;
            this.btn_Jumlahdepo.Click += new System.EventHandler(this.btn_Jumlahdepo_Click);
            // 
            // lb_Amount
            // 
            this.lb_Amount.AutoSize = true;
            this.lb_Amount.Location = new System.Drawing.Point(63, 90);
            this.lb_Amount.Name = "lb_Amount";
            this.lb_Amount.Size = new System.Drawing.Size(169, 20);
            this.lb_Amount.TabIndex = 1;
            this.lb_Amount.Text = "Input Deposit Amount:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(89, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 25);
            this.label4.TabIndex = 0;
            this.label4.Text = "UC Bank";
            // 
            // pan_with
            // 
            this.pan_with.Controls.Add(this.lb_numberwith);
            this.pan_with.Controls.Add(this.lb_Rpwith);
            this.pan_with.Controls.Add(this.lb_balancewith);
            this.pan_with.Controls.Add(this.tb_Jumlahwith);
            this.pan_with.Controls.Add(this.btn_logoutwith);
            this.pan_with.Controls.Add(this.btn_Jumlahwith);
            this.pan_with.Controls.Add(this.lb_withamount);
            this.pan_with.Controls.Add(this.lb_ucbankwith);
            this.pan_with.Location = new System.Drawing.Point(563, 301);
            this.pan_with.Name = "pan_with";
            this.pan_with.Size = new System.Drawing.Size(306, 238);
            this.pan_with.TabIndex = 10;
            this.pan_with.Visible = false;
            // 
            // lb_numberwith
            // 
            this.lb_numberwith.AutoSize = true;
            this.lb_numberwith.Location = new System.Drawing.Point(152, 90);
            this.lb_numberwith.Name = "lb_numberwith";
            this.lb_numberwith.Size = new System.Drawing.Size(44, 20);
            this.lb_numberwith.TabIndex = 9;
            this.lb_numberwith.Text = " 0,00";
            // 
            // lb_Rpwith
            // 
            this.lb_Rpwith.AutoSize = true;
            this.lb_Rpwith.Location = new System.Drawing.Point(128, 90);
            this.lb_Rpwith.Name = "lb_Rpwith";
            this.lb_Rpwith.Size = new System.Drawing.Size(30, 20);
            this.lb_Rpwith.TabIndex = 9;
            this.lb_Rpwith.Text = "Rp";
            // 
            // lb_balancewith
            // 
            this.lb_balancewith.AutoSize = true;
            this.lb_balancewith.Location = new System.Drawing.Point(51, 90);
            this.lb_balancewith.Name = "lb_balancewith";
            this.lb_balancewith.Size = new System.Drawing.Size(71, 20);
            this.lb_balancewith.TabIndex = 9;
            this.lb_balancewith.Text = "Balance:";
            // 
            // tb_Jumlahwith
            // 
            this.tb_Jumlahwith.Location = new System.Drawing.Point(67, 152);
            this.tb_Jumlahwith.Name = "tb_Jumlahwith";
            this.tb_Jumlahwith.Size = new System.Drawing.Size(142, 26);
            this.tb_Jumlahwith.TabIndex = 7;
            // 
            // btn_logoutwith
            // 
            this.btn_logoutwith.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_logoutwith.Location = new System.Drawing.Point(193, 44);
            this.btn_logoutwith.Name = "btn_logoutwith";
            this.btn_logoutwith.Size = new System.Drawing.Size(94, 30);
            this.btn_logoutwith.TabIndex = 7;
            this.btn_logoutwith.Text = "Log Out";
            this.btn_logoutwith.UseVisualStyleBackColor = true;
            this.btn_logoutwith.Click += new System.EventHandler(this.btn_logoutwith_Click);
            // 
            // btn_Jumlahwith
            // 
            this.btn_Jumlahwith.Location = new System.Drawing.Point(94, 184);
            this.btn_Jumlahwith.Name = "btn_Jumlahwith";
            this.btn_Jumlahwith.Size = new System.Drawing.Size(106, 36);
            this.btn_Jumlahwith.TabIndex = 5;
            this.btn_Jumlahwith.Text = "Withdraw";
            this.btn_Jumlahwith.UseVisualStyleBackColor = true;
            this.btn_Jumlahwith.Click += new System.EventHandler(this.btn_Jumlahwith_Click);
            // 
            // lb_withamount
            // 
            this.lb_withamount.AutoSize = true;
            this.lb_withamount.Location = new System.Drawing.Point(47, 125);
            this.lb_withamount.Name = "lb_withamount";
            this.lb_withamount.Size = new System.Drawing.Size(192, 20);
            this.lb_withamount.TabIndex = 1;
            this.lb_withamount.Text = "Input Withdrawal Amount:";
            // 
            // lb_ucbankwith
            // 
            this.lb_ucbankwith.AutoSize = true;
            this.lb_ucbankwith.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucbankwith.Location = new System.Drawing.Point(89, 20);
            this.lb_ucbankwith.Name = "lb_ucbankwith";
            this.lb_ucbankwith.Size = new System.Drawing.Size(98, 25);
            this.lb_ucbankwith.TabIndex = 0;
            this.lb_ucbankwith.Text = "UC Bank";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(989, 611);
            this.Controls.Add(this.pan_login);
            this.Controls.Add(this.pan_depo);
            this.Controls.Add(this.pan_with);
            this.Controls.Add(this.pan_regis);
            this.Controls.Add(this.pan_balance);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pan_login.ResumeLayout(false);
            this.pan_login.PerformLayout();
            this.pan_regis.ResumeLayout(false);
            this.pan_regis.PerformLayout();
            this.pan_balance.ResumeLayout(false);
            this.pan_balance.PerformLayout();
            this.pan_depo.ResumeLayout(false);
            this.pan_depo.PerformLayout();
            this.pan_with.ResumeLayout(false);
            this.pan_with.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pan_login;
        private System.Windows.Forms.Label lb_Pass;
        private System.Windows.Forms.Label lb_User;
        private System.Windows.Forms.Label lb_ucbank;
        private System.Windows.Forms.Button btn_Register;
        private System.Windows.Forms.Button btn_Login;
        private System.Windows.Forms.TextBox tb_pass;
        private System.Windows.Forms.TextBox tb_user;
        private System.Windows.Forms.Panel pan_regis;
        private System.Windows.Forms.Button btn_reg;
        private System.Windows.Forms.TextBox tb_passreg;
        private System.Windows.Forms.TextBox tb_userreg;
        private System.Windows.Forms.Label lb_pass2;
        private System.Windows.Forms.Label lb_user2;
        private System.Windows.Forms.Label lb_uc;
        private System.Windows.Forms.Panel pan_balance;
        private System.Windows.Forms.Button btn_withdraw;
        private System.Windows.Forms.Button btn_deposit;
        private System.Windows.Forms.Label lb_rp;
        private System.Windows.Forms.Label lb_balance;
        private System.Windows.Forms.Label lb_ucbalance;
        private System.Windows.Forms.Button btn_logout;
        private System.Windows.Forms.Label lb_number;
        private System.Windows.Forms.Panel pan_depo;
        private System.Windows.Forms.TextBox tb_Jumlahdepo;
        private System.Windows.Forms.Button btn_logoutdeposit;
        private System.Windows.Forms.Button btn_Jumlahdepo;
        private System.Windows.Forms.Label lb_Amount;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel pan_with;
        private System.Windows.Forms.TextBox tb_Jumlahwith;
        private System.Windows.Forms.Button btn_logoutwith;
        private System.Windows.Forms.Button btn_Jumlahwith;
        private System.Windows.Forms.Label lb_withamount;
        private System.Windows.Forms.Label lb_ucbankwith;
        private System.Windows.Forms.Label lb_balancewith;
        private System.Windows.Forms.Label lb_numberwith;
        private System.Windows.Forms.Label lb_Rpwith;
    }
}

