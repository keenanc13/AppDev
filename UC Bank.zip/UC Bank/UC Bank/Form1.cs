﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UC_Bank
{
    public partial class Form1 : Form
    {
        List <string> username = new List <string> ();
        List <string> password = new List <string> ();
        List <long> balance = new List <long> ();
        int count;
        public Form1()
        {
            InitializeComponent();
            pan_login.Top = 12;
            pan_login.Left = 19;
            pan_with.Top = 12;
            pan_with.Left = 19;
            pan_regis.Top = 12;
            pan_regis.Left = 19;
            pan_balance.Top = 12;
            pan_balance.Left = 19;
            pan_depo.Top = 12;
            pan_depo.Left = 19;
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            if (username.Count == 0)
            {
                MessageBox.Show("Register Dulu");
            }
            else
            {
                string name = tb_user.Text;
                string word = tb_pass.Text;
                bool login = false;
                for(int i  = 0; i < username.Count;i++)
                {
                    if (username[i] == name && password[i] == word)
                    {
                        login = true;
                        count = i;
                    }
                }

                if (login == false)
                {
                    MessageBox.Show("Username tidak sesuai");
                }
                else 
                {
                    tb_user.Clear();
                    tb_pass.Clear();
                    pan_balance.Visible = true;
                    pan_login.Visible = false;
                    tb_user.Text = "";
                    tb_pass.Text = "";
                    lb_number.Text = balance[count].ToString();
                }
            }
        }

        private void btn_Register_Click(object sender, EventArgs e)
        {
            pan_regis.Visible = true;
            pan_login.Visible = false;
            tb_user.Text = "";
            tb_pass.Text = "";
        }

        private void btn_reg_Click(object sender, EventArgs e)
        {
            string user = tb_userreg.Text;
            string pass = tb_passreg.Text;

            if (username.Contains(user))
            {
                MessageBox.Show("Username sudah ada");
            }
            else
            {
                username.Add(user);
                password.Add(pass);
                balance.Add(0);
                MessageBox.Show("Register berhasil");
                pan_login.Visible = true;
                pan_regis.Visible = false;
                tb_userreg.Text = "";
                tb_passreg.Text = "";
                lb_number.Text = balance[count].ToString();
            }
        }

        private void btn_deposit_Click(object sender, EventArgs e)
        {
            pan_depo.Visible = true;
            pan_balance.Visible = false;
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            pan_login.Visible = true;
            pan_balance.Visible=false;
        }

        private void btn_logoutdeposit_Click(object sender, EventArgs e)
        {
            pan_login.Visible = true;
            pan_depo.Visible = false;
        }

        private void btn_Jumlahdepo_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt64(tb_Jumlahdepo.Text) <= 0)
            {
                MessageBox.Show("Deposit Failed");
            }
            else
            {
                MessageBox.Show("Succesfully Add Deposit");
                balance[count] = balance[count] + Convert.ToInt32(tb_Jumlahdepo.Text);
                lb_number.Text = balance[count].ToString( "N2", CultureInfo.InvariantCulture);
                tb_Jumlahdepo.Text = "";
                pan_depo.Visible = false;
                pan_balance.Visible = true;
            }

        }

        private void btn_withdraw_Click(object sender, EventArgs e)
        {
            pan_with.Visible = true;
            pan_balance.Visible = false;
            lb_numberwith.Text = lb_number.Text;
        }

        private void btn_Jumlahwith_Click(object sender, EventArgs e)
        {
            long kevin = Convert.ToInt64(tb_Jumlahwith.Text);
            if (kevin <= 0 || kevin > balance[count] || kevin == 0)
            {
                MessageBox.Show("Withdraw Failed");
            }
            else
            {
                MessageBox.Show("Withdraw Succesful");
                pan_balance.Visible = true;
                pan_with.Visible = false;
                balance[count] = balance[count] - Convert.ToInt32(tb_Jumlahwith.Text);
                lb_numberwith.Text = balance[count].ToString("N2", CultureInfo.InvariantCulture);
                lb_number.Text = balance[count].ToString("N2", CultureInfo.InvariantCulture);
                tb_Jumlahwith.Text = "";
            }
        }

        private void btn_logoutwith_Click(object sender, EventArgs e)
        {
            pan_balance.Visible = true;
            pan_with.Visible=false;
        }
    }
}
