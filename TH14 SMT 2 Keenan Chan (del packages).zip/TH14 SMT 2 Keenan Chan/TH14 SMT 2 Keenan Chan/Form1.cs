﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.SqlServer.Server;
using MySql.Data.MySqlClient;

namespace TH14_SMT_2_Keenan_Chan
{
    public partial class Form1 : Form
    {
        MySqlConnection conn;
        MySqlCommand cmd;
        MySqlDataAdapter adapt;
        string query;
        DataTable dt = new DataTable();
        DataTable dtHome = new DataTable();
        DataTable dtAway = new DataTable();
        DataTable players;
        DataTable dmatch = new DataTable();

        string lastdate = "2/14/2016 12:00:00 AM";
        int index;
        string idteam;
        string idhome;
        string idaway;
        int goalhome = 0;
        int goalaway = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            conn = new MySqlConnection($"server = localhost; uid = root; pwd = Keenanuc2023; database = premier_league");
            conn.Open();
            conn.Close();
            query = "select team_id,team_name from team";
            cmd = new MySqlCommand(query, conn);
            adapt = new MySqlDataAdapter(cmd);
            adapt.Fill(dtHome);
            adapt.Fill(dtAway);
            combo_home.DataSource = dtHome;
            combo_home.DisplayMember = "team_name";
            combo_home.ValueMember = "team_id";
            combo_away.DataSource = dtAway;
            combo_away.DisplayMember = "team_name";
            combo_away.ValueMember = "team_id";
            dt.Columns.Add("Minute");
            dt.Columns.Add("Team");
            dt.Columns.Add("Player");
            dt.Columns.Add("Type");

            dmatch = new DataTable();
            dmatch.Columns.Add("match_id");
            dmatch.Columns.Add("minute");
            dmatch.Columns.Add("team_id");
            dmatch.Columns.Add("player_id");
            dmatch.Columns.Add("type");
            dmatch.Columns.Add("delete");

            combo_home.Text = "";
            combo_away.Text = "";
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            dt.Rows.Add(tb_minute.Text, combo_home.Text, combo_player.Text, combo_type.Text);
            dgv_main.DataSource = dt;
            dmatch.Rows.Add(tb_matchid.Text, tb_minute.Text, idteam, combo_player.SelectedValue, combo_type.Text, 0);
        }

        private void dtp_match_ValueChanged(object sender, EventArgs e)
        {
            string year = dtp_match.Value.Year.ToString();

            if(dtp_match.Value < Convert.ToDateTime(lastdate))
            {
                MessageBox.Show("Tanggal tidak bisa kurang dari pertandingan terakhir");
                btn_insert.Enabled = false;
            }
            else
            {
                btn_insert.Enabled=true;
                query = $"select count(match_id) from `match` where match_id like '{year}%';";
                cmd = new MySqlCommand(query, conn);
                adapt = new MySqlDataAdapter (cmd);

                DataTable dtCount = new DataTable();
                adapt.Fill (dtCount);               

                if (Convert.ToInt32(dtCount.Rows[0][0]) < 10)
                {
                    tb_matchid.Text = $"{year}00{(Convert.ToInt32(dtCount.Rows[0][0])+1).ToString()}";
                }
                else if (Convert.ToInt32(dtCount.Rows[0][0]) >= 10 && Convert.ToInt32(dtCount.Rows[0][0]) < 100)
                {
                    tb_matchid.Text = $"{year}0{(Convert.ToInt32(dtCount.Rows[0][0]) + 1).ToString()}";
                }
                else if(Convert.ToInt32(dtCount.Rows[0][0]) >= 100)
                {
                    tb_matchid.Text = $"{year}{(Convert.ToInt32(dtCount.Rows[0][0]) + 1).ToString()}";
                }
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            dt.Rows.RemoveAt(index);
            dgv_main.DataSource = dt;
            dmatch.Rows.RemoveAt(index);
        }

        private void dgv_main_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
        }

        private void combo_home_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if(combo_home.SelectedIndex == -1 && combo_away.SelectedIndex == -1)
                {

                }
                else
                {
                    if (combo_home.Text == combo_away.Text)
                    {
                        MessageBox.Show("Tim tidak boleh sama");
                    }
                    else
                    {
                        combo_team.Items.Clear();
                        idhome = Convert.ToString(combo_home.SelectedValue);
                        idaway = Convert.ToString(combo_away.SelectedValue);
                        combo_team.Items.Add(combo_home.Text);
                        combo_team.Items.Add(combo_away.Text);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void combo_away_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (combo_home.SelectedIndex == -1 && combo_away.SelectedIndex == -1)
                {

                }
                else
                {
                    if (combo_home.Text == combo_away.Text)
                    {
                        MessageBox.Show("Tim tidak boleh sama");
                    }
                    else
                    {
                        combo_team.Items.Clear();
                        idhome = Convert.ToString(combo_home.SelectedValue);
                        idaway = Convert.ToString(combo_away.SelectedValue);
                        combo_team.Items.Add(combo_home.Text);
                        combo_team.Items.Add(combo_away.Text);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void combo_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            players = new DataTable();
            if(combo_team.SelectedIndex == 0)
            {
                idteam = idhome;
            }
            if(combo_team.SelectedIndex == 1)
            {
                idteam = idaway;
            }
            query = $"select player_id,player_name from player where team_id like '%{idteam}%';";
            cmd = new MySqlCommand(query, conn);
            adapt = new MySqlDataAdapter(cmd);
            adapt.Fill(players);
            combo_player.DataSource = players;
            combo_player.DisplayMember = "player_name";
            combo_player.ValueMember = "player_id";
            combo_player.Text = "";
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            bool tanggalBenar = false;
            if (dtp_match.Value.Year == 2016 && dtp_match.Value.Month == 2 && dtp_match.Value.Day >= 14)
            {


                tanggalBenar = true;
            }
            else if (dtp_match.Value.Year == 2016 && dtp_match.Value.Month > 2)
            {
                tanggalBenar = true;
            }
            else if (dtp_match.Value.Year > 2016)
            {
                tanggalBenar = true;
            }
            else
            {

                tanggalBenar = false;
            }

            if (tanggalBenar)
            {
                try
                {
                    conn.Open();
                    for (int i = 0; i < dmatch.Rows.Count; i++)
                    {
                        query = $"insert into dmatch values ({dmatch.Rows[i][0]}, {dmatch.Rows[i][1]}, '{dmatch.Rows[i][2]}', '{dmatch.Rows[i][3]}', '{dmatch.Rows[i][4]}', {dmatch.Rows[i][5]});";
                        cmd = new MySqlCommand(query, conn);
                        cmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                int scorehome = 0;
                int scoreaway = 0;
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i][1].ToString() == combo_home.Text)
                    {
                        if (dt.Rows[i][3].ToString() == "GO" || dt.Rows[i][3].ToString() == "GP")
                        {
                            scorehome++;
                        }
                        else if (dt.Rows[i][3].ToString() == "GW")
                        {
                            scoreaway++;
                        }
                    }
                    else
                    {
                        if (dt.Rows[i][3].ToString() == "GO" || dt.Rows[i][3].ToString() == "GP")
                        {
                            scoreaway++;
                        }
                        else if (dt.Rows[i][3].ToString() == "GW")
                        {
                            scorehome++;
                        }
                    }
                }
                try
                {
                    query = $"insert into `match` values ('{tb_matchid.Text}', '{dtp_match.Value.ToString("yyyy-MM-dd")}', '{idhome}', '{idaway}', {scorehome}, {scoreaway}, 'M002', 0);";
                    cmd = new MySqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    conn.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Tanggal tidak valid");
            }
        }
    }
}
