﻿namespace TH14_SMT_2_Keenan_Chan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_matchid = new System.Windows.Forms.Label();
            this.lb_teamhome = new System.Windows.Forms.Label();
            this.lb_matchdate = new System.Windows.Forms.Label();
            this.lb_teamaway = new System.Windows.Forms.Label();
            this.tb_matchid = new System.Windows.Forms.TextBox();
            this.combo_home = new System.Windows.Forms.ComboBox();
            this.combo_away = new System.Windows.Forms.ComboBox();
            this.dtp_match = new System.Windows.Forms.DateTimePicker();
            this.dgv_main = new System.Windows.Forms.DataGridView();
            this.lb_minute = new System.Windows.Forms.Label();
            this.lb_team = new System.Windows.Forms.Label();
            this.lb_player = new System.Windows.Forms.Label();
            this.lb_type = new System.Windows.Forms.Label();
            this.tb_minute = new System.Windows.Forms.TextBox();
            this.combo_team = new System.Windows.Forms.ComboBox();
            this.combo_player = new System.Windows.Forms.ComboBox();
            this.combo_type = new System.Windows.Forms.ComboBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_insert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_main)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_matchid
            // 
            this.lb_matchid.AutoSize = true;
            this.lb_matchid.Location = new System.Drawing.Point(43, 50);
            this.lb_matchid.Name = "lb_matchid";
            this.lb_matchid.Size = new System.Drawing.Size(78, 20);
            this.lb_matchid.TabIndex = 0;
            this.lb_matchid.Text = "Match ID:";
            // 
            // lb_teamhome
            // 
            this.lb_teamhome.AutoSize = true;
            this.lb_teamhome.Location = new System.Drawing.Point(21, 116);
            this.lb_teamhome.Name = "lb_teamhome";
            this.lb_teamhome.Size = new System.Drawing.Size(100, 20);
            this.lb_teamhome.TabIndex = 1;
            this.lb_teamhome.Text = "Team Home:";
            // 
            // lb_matchdate
            // 
            this.lb_matchdate.AutoSize = true;
            this.lb_matchdate.Location = new System.Drawing.Point(565, 47);
            this.lb_matchdate.Name = "lb_matchdate";
            this.lb_matchdate.Size = new System.Drawing.Size(96, 20);
            this.lb_matchdate.TabIndex = 2;
            this.lb_matchdate.Text = "Match Date:";
            // 
            // lb_teamaway
            // 
            this.lb_teamaway.AutoSize = true;
            this.lb_teamaway.Location = new System.Drawing.Point(565, 122);
            this.lb_teamaway.Name = "lb_teamaway";
            this.lb_teamaway.Size = new System.Drawing.Size(95, 20);
            this.lb_teamaway.TabIndex = 3;
            this.lb_teamaway.Text = "Team Away:";
            // 
            // tb_matchid
            // 
            this.tb_matchid.Location = new System.Drawing.Point(127, 47);
            this.tb_matchid.Name = "tb_matchid";
            this.tb_matchid.Size = new System.Drawing.Size(221, 26);
            this.tb_matchid.TabIndex = 4;
            // 
            // combo_home
            // 
            this.combo_home.FormattingEnabled = true;
            this.combo_home.Location = new System.Drawing.Point(127, 114);
            this.combo_home.Name = "combo_home";
            this.combo_home.Size = new System.Drawing.Size(221, 28);
            this.combo_home.TabIndex = 5;
            this.combo_home.SelectedIndexChanged += new System.EventHandler(this.combo_home_SelectedIndexChanged);
            // 
            // combo_away
            // 
            this.combo_away.FormattingEnabled = true;
            this.combo_away.Location = new System.Drawing.Point(666, 119);
            this.combo_away.Name = "combo_away";
            this.combo_away.Size = new System.Drawing.Size(221, 28);
            this.combo_away.TabIndex = 7;
            this.combo_away.SelectedIndexChanged += new System.EventHandler(this.combo_away_SelectedIndexChanged);
            // 
            // dtp_match
            // 
            this.dtp_match.Location = new System.Drawing.Point(666, 45);
            this.dtp_match.Name = "dtp_match";
            this.dtp_match.Size = new System.Drawing.Size(275, 26);
            this.dtp_match.TabIndex = 8;
            this.dtp_match.ValueChanged += new System.EventHandler(this.dtp_match_ValueChanged);
            // 
            // dgv_main
            // 
            this.dgv_main.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_main.Location = new System.Drawing.Point(32, 228);
            this.dgv_main.Name = "dgv_main";
            this.dgv_main.RowHeadersWidth = 62;
            this.dgv_main.RowTemplate.Height = 28;
            this.dgv_main.Size = new System.Drawing.Size(571, 272);
            this.dgv_main.TabIndex = 9;
            this.dgv_main.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_main_CellClick);
            // 
            // lb_minute
            // 
            this.lb_minute.AutoSize = true;
            this.lb_minute.Location = new System.Drawing.Point(648, 265);
            this.lb_minute.Name = "lb_minute";
            this.lb_minute.Size = new System.Drawing.Size(61, 20);
            this.lb_minute.TabIndex = 10;
            this.lb_minute.Text = "Minute:";
            // 
            // lb_team
            // 
            this.lb_team.AutoSize = true;
            this.lb_team.Location = new System.Drawing.Point(656, 314);
            this.lb_team.Name = "lb_team";
            this.lb_team.Size = new System.Drawing.Size(53, 20);
            this.lb_team.TabIndex = 11;
            this.lb_team.Text = "Team:";
            // 
            // lb_player
            // 
            this.lb_player.AutoSize = true;
            this.lb_player.Location = new System.Drawing.Point(653, 362);
            this.lb_player.Name = "lb_player";
            this.lb_player.Size = new System.Drawing.Size(56, 20);
            this.lb_player.TabIndex = 12;
            this.lb_player.Text = "Player:";
            // 
            // lb_type
            // 
            this.lb_type.AutoSize = true;
            this.lb_type.Location = new System.Drawing.Point(662, 413);
            this.lb_type.Name = "lb_type";
            this.lb_type.Size = new System.Drawing.Size(47, 20);
            this.lb_type.TabIndex = 13;
            this.lb_type.Text = "Type:";
            // 
            // tb_minute
            // 
            this.tb_minute.Location = new System.Drawing.Point(715, 262);
            this.tb_minute.Name = "tb_minute";
            this.tb_minute.Size = new System.Drawing.Size(188, 26);
            this.tb_minute.TabIndex = 14;
            // 
            // combo_team
            // 
            this.combo_team.FormattingEnabled = true;
            this.combo_team.Location = new System.Drawing.Point(715, 311);
            this.combo_team.Name = "combo_team";
            this.combo_team.Size = new System.Drawing.Size(187, 28);
            this.combo_team.TabIndex = 15;
            this.combo_team.SelectedIndexChanged += new System.EventHandler(this.combo_team_SelectedIndexChanged);
            // 
            // combo_player
            // 
            this.combo_player.FormattingEnabled = true;
            this.combo_player.Location = new System.Drawing.Point(715, 362);
            this.combo_player.Name = "combo_player";
            this.combo_player.Size = new System.Drawing.Size(187, 28);
            this.combo_player.TabIndex = 16;
            // 
            // combo_type
            // 
            this.combo_type.FormattingEnabled = true;
            this.combo_type.Items.AddRange(new object[] {
            "GO",
            "GP",
            "GP",
            "CR",
            "CP",
            "PY"});
            this.combo_type.Location = new System.Drawing.Point(715, 410);
            this.combo_type.Name = "combo_type";
            this.combo_type.Size = new System.Drawing.Size(187, 28);
            this.combo_type.TabIndex = 17;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(652, 457);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(102, 32);
            this.btn_add.TabIndex = 18;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(810, 457);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(117, 32);
            this.btn_delete.TabIndex = 19;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(398, 540);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(275, 39);
            this.btn_insert.TabIndex = 20;
            this.btn_insert.Text = "Insert";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1116, 649);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.combo_type);
            this.Controls.Add(this.combo_player);
            this.Controls.Add(this.combo_team);
            this.Controls.Add(this.tb_minute);
            this.Controls.Add(this.lb_type);
            this.Controls.Add(this.lb_player);
            this.Controls.Add(this.lb_team);
            this.Controls.Add(this.lb_minute);
            this.Controls.Add(this.dgv_main);
            this.Controls.Add(this.dtp_match);
            this.Controls.Add(this.combo_away);
            this.Controls.Add(this.combo_home);
            this.Controls.Add(this.tb_matchid);
            this.Controls.Add(this.lb_teamaway);
            this.Controls.Add(this.lb_matchdate);
            this.Controls.Add(this.lb_teamhome);
            this.Controls.Add(this.lb_matchid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_main)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_matchid;
        private System.Windows.Forms.Label lb_teamhome;
        private System.Windows.Forms.Label lb_matchdate;
        private System.Windows.Forms.Label lb_teamaway;
        private System.Windows.Forms.TextBox tb_matchid;
        private System.Windows.Forms.ComboBox combo_home;
        private System.Windows.Forms.ComboBox combo_away;
        private System.Windows.Forms.DateTimePicker dtp_match;
        private System.Windows.Forms.DataGridView dgv_main;
        private System.Windows.Forms.Label lb_minute;
        private System.Windows.Forms.Label lb_team;
        private System.Windows.Forms.Label lb_player;
        private System.Windows.Forms.Label lb_type;
        private System.Windows.Forms.TextBox tb_minute;
        private System.Windows.Forms.ComboBox combo_team;
        private System.Windows.Forms.ComboBox combo_player;
        private System.Windows.Forms.ComboBox combo_type;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_insert;
    }
}

